# AGENTS.md — futebolfer/futbol (Startup Deportiva)

Antes de escribir código, lee TODO /docs/spec/*.md y /docs/skills/*.md en orden numérico.
No inventes actores, entidades, reglas de permisos ni agentes que no estén documentados ahí.

## Orden de lectura obligatorio
1. docs/spec/00-master-roadmap.md (documento fuente completo: Etapas 1-19)
2. docs/spec/09-agentes-producto.md (contrato exacto de los 9 agentes de producto, Etapa 17)
3. docs/spec/10-arquitectura-datos.md (20 entidades/tablas, Etapa 18)
4. docs/spec/11-arquitectura-tecnica.md (stack candidato por capa, Etapa 19)
5. docs/skills/*.md (agentes de negocio/growth y agente Geo, con sus subagentes)

## Reglas no negociables (extraídas del documento maestro)
- No mostrar coordenadas exactas de menores de edad; ofuscar siempre (Agente 1 de Geo).
- Consentimiento parental obligatorio antes de crear o exponer el perfil de un menor.
- Contacto directo oculto por defecto; se revela solo con opt-in mutuo, nunca automático tras un match.
- Historial de clubes es OBLIGATORIO solo si el jugador declaró experiencia previa / club (no para todo jugador).
- No inventar verificaciones: si no hay fuente oficial (COMET u otra), etiquetar el dato como "declarado", nunca como "verificado".
- No construir funciones porque se puede; construir capacidades porque resuelven una necesidad ya documentada (regla maestra, sección 32 del roadmap).
- Alcance del MVP: TODOS los actores documentados están desde el lanzamiento (Jugador, Niño/Joven + Familia, Club, Academia, Scout, Entrenador, Preparador físico, Fisioterapeuta, Asistente, Staff, Utillero, Otros profesionales), con alcance funcional inicial simplificado para Scout y profesionales (Etapa 15, corregido).
- La interfaz se organiza en 6 grupos contextuales de entrada (Jugadores, Niño/Familia, Clubes, Academias, Profesionales, Scouts), asignados automáticamente por tipo de actor declarado en el perfil — nunca por un menú manual (sección 4 del roadmap, actualizado esta sesión).
- La plataforma NO es de pago para los actores documentados (regla 42).
- Cada agente de producto es un contrato: Rol, Entrada, Contexto/Datos, Instrucción Core, Freno, Salida, Siguiente agente, Verificación — no implementar un agente sin sus 8 campos definidos.

## Estado del proyecto al momento de esta transferencia
- Especificación (Etapas 1-19): completa a nivel conceptual/documental.
- Implementación (Etapa 20 en adelante): no iniciada. Este repo es el punto de partida.
- Bloqueado por acceso externo (no técnico): integración con sistema COMET (ver backlog, sección 35-36 del roadmap).
