<callout icon="📅" color="gray_bg">
Documento maestro de continuidad — Agosto 2026
</callout>

<p />

<callout icon="⚠️" color="yellow_bg">
Este documento consolida únicamente lo construido textualmente en la conversación. Donde una matriz fue mencionada pero su tabla completa no está disponible aquí, se señala explícitamente como <b>pendiente de recuperar</b> en vez de inventar su contenido.
</callout>

<table-of-contents />

#

1. Definición general del proyecto

Estamos construyendo una <b>plataforma/software deportivo contextual</b> que conecta diferentes actores del ecosistema deportivo y utiliza información estructurada, contexto, reglas, geolocalización y agentes de IA para:

- Detectar perfiles
- Detectar necesidades
- Descubrir oportunidades
- Encontrar clubes, academias, tryouts, jugadores, staff
- Encontrar fisioterapeutas, preparadores físicos, entrenadores, asistentes
- Facilitar conexiones y hacer matching
- Priorizar resultados y generar recomendaciones
- Ahorrar tiempo de búsqueda
- Adaptar la experiencia a cada usuario

<quote color="red_bg">
La plataforma <b>NO es únicamente</b> scouting, directorio de clubes, buscador de jugadores, plataforma de academias, marketplace de profesionales, mapa deportivo, bolsa de trabajo, ni red social deportiva.
</quote>

Es un sistema que busca <b>integrar esas necesidades dentro de un mismo ecosistema contextual</b>.

#

1. El problema central

<callout icon="🎯" color="blue_bg">
La información y las oportunidades del ecosistema deportivo están fragmentadas, y cada actor necesita una combinación diferente de esa información para tomar decisiones. Esto genera pérdida de tiempo y fricción.
</callout>

## Necesidades por actor

<toggle heading="h3">
Niño / joven
</toggle>

Comenzar a entrenar, encontrar academia o club, conocer categorías, competición, precio, ubicación, horarios, saber si puede entrar directamente o si existen tryouts.

<toggle heading="h3">
Jugador que ya pertenece a un club
</toggle>

Otro club, una oportunidad, tryout, scouting, entrenador personal, preparador físico, fisioterapeuta, recuperación, servicios complementarios.

<toggle heading="h3">
Familia
</toggle>

Opciones cercanas, precio, categoría, competición, seguridad, horarios, características del club, información sobre formación.

<toggle heading="h3">
Club
</toggle>

Jugadores con determinados perfiles/categoría/posición/contexto competitivo, tryouts, entrenador, fisioterapeuta, preparador físico, asistentes, staff, servicios.

<toggle heading="h3">
Scout
</toggle>

Detectar jugadores, filtrar por características, competición, categoría, club, ubicación, oportunidades, contexto.

<toggle heading="h3">
Fisioterapeuta
</toggle>

Deportistas, clubes, equipos, oportunidades profesionales.

<toggle heading="h3">
Preparador físico
</toggle>

Jugadores, clubes, equipos, oportunidades.

<toggle heading="h3">
Entrenador
</toggle>

Jugadores, clubes, equipos, oportunidades laborales.

#

2. La respuesta del producto

La plataforma busca pasar de:

```txt
INFORMACIÓN FRAGMENTADA
        ↓
USUARIO BUSCANDO MANUALMENTE
        ↓
MUCHO TIEMPO
        ↓
MUCHA FRICCIÓN
```

a:

```txt
PERFIL + CONTEXTO + NECESIDAD + DATOS + UBICACIÓN + RELACIONES
        ↓
     SISTEMA
        ↓
  DESCUBRIMIENTO
        ↓
     FILTRADO
        ↓
     MATCHING
        ↓
   PRIORIZACIÓN
        ↓
   RECOMENDACIÓN
        ↓
      ACCIÓN
```

#

3. Principio fundamental de UX

<callout icon="🚫" color="red_bg">
<b>NO queremos:</b> preguntar "¿Qué estás buscando?" al entrar y obligar al usuario a navegar una lista enorme de funcionalidades. Eso transfiere al usuario el trabajo de entender el sistema.
</callout>

<callout icon="✅" color="green_bg">
<b>Sí queremos:</b> el usuario crea su perfil, la plataforma obtiene su contexto, y de ahí interpreta y recomienda.
</callout>

```txt
PERFIL → CONTEXTO → INTERPRETACIÓN → RECOMENDACIONES / EXPERIENCIA
```

<b>Ejemplo:</b> un niño de 11 años, sin club, sin experiencia, ubicación X → la plataforma infiere que son relevantes academias, clubes, entrenamientos, programas de iniciación. No necesita ver de entrada scouting profesional, búsqueda avanzada de jugadores, staff, u oportunidades laborales.

#

4. El sistema no debe estar sobrecargado

Tener muchas capacidades no significa mostrar muchas funciones simultáneamente. La interfaz organiza las capacidades por grandes grupos contextuales, subordinados siempre al contexto del usuario:

<callout icon="🔄" color="blue_bg">
Actualizado esta sesión (Arquitecto de Ecosistema): de 4 a 6 grupos de entrada, para reflejar que todos los actores documentados entran desde el MVP (Etapa 15). Esta sigue siendo una definición conceptual de agrupación, no el diseño visual de la interfaz (eso es Etapa 20).
</callout>

<columns>
<column ratio="16">
<b>JUGADORES</b>

- Buscar club
- Buscar oportunidad
- Buscar tryout
- Buscar profesional
</column>
<column ratio="16">
<b>NIÑO / FAMILIA</b>

- Buscar academia o club de iniciación
- Ver requisitos y tryouts de acceso
- Iniciar proceso (consentimiento parental)
</column>
<column ratio="17">
<b>CLUBES</b>

- Buscar jugadores
- Buscar staff
- Buscar profesionales
- Crear tryout
- Publicar necesidad
</column>
<column ratio="17">
<b>ACADEMIAS</b>

- Publicar programas y categorías
- Gestionar inscripciones
- Buscar entrenadores
</column>
<column ratio="17">
<b>PROFESIONALES</b>

- Buscar oportunidades
- Buscar clubes/academias
- Ofrecer servicios
</column>
<column ratio="17">
<b>SCOUTS</b>

- Buscar perfiles
- Filtrar jugadores
- Detectar oportunidades
</column>
</columns>

<callout icon="💡" color="purple_bg">
Regla de asignación de grupo (coherente con el Principio de UX, sección 3): el grupo no se elige manualmente en un menú; se determina automáticamente por el tipo de actor declarado en el perfil (Etapa 15, orden de construcción #1). El usuario nunca ve los 6 grupos como opciones —ve directamente su propio grupo.
</callout>

#

5. Actores del ecosistema

<callout icon="📌">
Decisión fijada: los actores varían según el perfil del usuario. No se construye pensando que todos tienen los mismos atributos.
</callout>

- Jugador
- Niño / joven
- Familia / representante
- Club
- Academia
- Equipo
- Scout
- Entrenador
- Preparador físico
- Fisioterapeuta
- Asistente
- Staff
- Utillero
- Otros profesionales de apoyo

<i>La lista puede evolucionar cuando termine el modelado completo de actores.</i>

<callout icon="✅" color="green_bg">
Cierre de Etapas 1-8 (fundamentos: Definición general del proyecto, Problema central, Respuesta del producto, Principio de UX, Sistema no sobrecargado por grupos contextuales, Actores del ecosistema, Perfil como núcleo, Club actual del jugador, Eliminación del campo "nivel"). Auditoría aplicada esta sesión (Auditor QA + Analista de Viabilidad, freno "no inventar datos", metodología sección 35): se verificó que estas etapas fundacionales son consistentes con todo lo construido después (Etapas 9-19) y que las dos correcciones ya aplicadas siguen vigentes — alcance condicional de "club actual"/historial (sección 7) y el listado completo de actores (sección 5).
</callout>

<callout icon="✅" color="green_bg">
Resuelto esta sesión (Arquitecto de Ecosistema): el hallazgo de agrupación incompleta de la interfaz (4 grupos vs. todos los actores del MVP) ya tiene solución conceptual aplicada en la sección "El sistema no debe estar sobrecargado" — ahora son 6 grupos (Jugadores, Niño/Familia, Clubes, Academias, Profesionales, Scouts), asignados automáticamente por tipo de actor, sin menú manual. El diseño visual concreto de estos grupos sigue correspondiendo a la Etapa 20 (Interfaz).
</callout>

## Matriz de Actores y Roles (Etapa 9 — completa)

<callout icon="✅" color="green_bg">
Cierre de Etapa 9. Esta matriz define, para cada actor: qué puede hacer, qué información necesita ver, qué puede publicar/ofrecer, y con quién se relaciona. El detalle exhaustivo de atributos/datos (Etapa 10) y el mapeo formal de relaciones (Etapa 11) y permisos (Etapa 12) siguen pendientes de cierre.
</callout>

<table>
<tr>
<td>
Actor
</td>
<td>
Qué puede hacer
</td>
<td>
Qué información necesita ver
</td>
<td>
Qué puede publicar/ofrecer
</td>
<td>
Con quién se relaciona
</td>
</tr>
<tr>
<td>
Jugador (con club)
</td>
<td>
Crear perfil, buscar otro club/academia, buscar oportunidad o tryout, buscar profesionales (entrenador personal, preparador físico, fisioterapeuta)
</td>
<td>
Clubes/academias cercanos, categorías, competiciones, tryouts abiertos, oportunidades según su perfil y contexto
</td>
<td>
Disponibilidad, trayectoria, videos/highlights, historial deportivo
</td>
<td>
Club actual, Scout, Entrenador, Preparador físico, Fisioterapeuta, Familia
</td>
</tr>
<tr>
<td>
Niño / joven (sin club/experiencia)
</td>
<td>
Crear perfil inicial (con tutor), explorar academias/clubes de iniciación
</td>
<td>
Opciones de iniciación cercanas, categorías por edad, precio, horarios, si requiere tryout
</td>
<td>
Perfil básico de interés en iniciarse
</td>
<td>
Familia (obligatorio), Academia, Club
</td>
</tr>
<tr>
<td>
Familia / Representante
</td>
<td>
Gestionar el perfil del menor, buscar y comparar opciones, contactar clubes/academias, autorizar visibilidad de datos
</td>
<td>
Seguridad, ubicación, precio, categoría, competición, información del club, horarios
</td>
<td>
Preferencias y restricciones (presupuesto, distancia, horarios)
</td>
<td>
Niño/joven, Club, Academia
</td>
</tr>
<tr>
<td>
Club
</td>
<td>
Publicar necesidad de jugadores/staff, crear tryouts, buscar jugadores por perfil, buscar profesionales
</td>
<td>
Perfiles de jugadores por posición/categoría/ubicación, disponibilidad de profesionales
</td>
<td>
Vacantes, tryouts, información institucional (categorías, precios, horarios, servicios)
</td>
<td>
Jugador, Academia, Scout, Entrenador, Preparador físico, Fisioterapeuta, Staff, Utillero, Asistente
</td>
</tr>
<tr>
<td>
Academia
</td>
<td>
Publicar programas/categorías, gestionar inscripciones, buscar entrenadores
</td>
<td>
Demanda por zona/edad, jugadores/niños interesados
</td>
<td>
Programas de formación, precios, horarios, tryouts de acceso
</td>
<td>
Niño/joven, Familia, Jugador, Entrenador
</td>
</tr>
<tr>
<td>
Equipo (dentro de un club, por categoría/temporada)
</td>
<td>
Gestionar plantilla, publicar necesidades específicas por categoría/temporada
</td>
<td>
Jugadores disponibles para su categoría/competición
</td>
<td>
Necesidades puntuales de refuerzo
</td>
<td>
Club (pertenece a), Jugador, Entrenador, Staff
</td>
</tr>
<tr>
<td>
Scout
</td>
<td>
Filtrar jugadores por características/competición/categoría/club/ubicación, guardar y priorizar perfiles, generar reportes
</td>
<td>
Perfiles detallados de jugadores, trayectoria, contexto competitivo
</td>
<td>
Reportes de scouting, recomendaciones a clubes
</td>
<td>
Jugador, Club
</td>
</tr>
<tr>
<td>
Entrenador
</td>
<td>
Buscar oportunidades laborales, ofrecer servicios, buscar jugadores/equipos
</td>
<td>
Vacantes en clubes/academias, jugadores/equipos que necesiten entrenador
</td>
<td>
Perfil profesional, experiencia, disponibilidad
</td>
<td>
Club, Academia, Equipo, Jugador
</td>
</tr>
<tr>
<td>
Preparador físico
</td>
<td>
Buscar oportunidades, ofrecer servicios a jugadores/clubes
</td>
<td>
Jugadores/clubes/equipos con necesidad de preparación física
</td>
<td>
Perfil profesional, planes de trabajo, disponibilidad
</td>
<td>
Jugador, Club, Equipo
</td>
</tr>
<tr>
<td>
Fisioterapeuta
</td>
<td>
Buscar oportunidades profesionales, ofrecer servicios
</td>
<td>
Deportistas/clubes/equipos que requieran atención
</td>
<td>
Perfil profesional, servicios, disponibilidad
</td>
<td>
Jugador, Club, Equipo
</td>
</tr>
<tr>
<td>
Asistente
</td>
<td>
Apoyar gestión del club/equipo/staff, buscar oportunidades
</td>
<td>
Vacantes de apoyo en clubes/equipos
</td>
<td>
Perfil profesional, disponibilidad
</td>
<td>
Club, Staff, Equipo
</td>
</tr>
<tr>
<td>
Staff (genérico)
</td>
<td>
Gestionar funciones administrativas/operativas del club, buscar oportunidades
</td>
<td>
Necesidades operativas del club/equipo
</td>
<td>
Perfil profesional, funciones que cubre
</td>
<td>
Club, Equipo
</td>
</tr>
<tr>
<td>
Utillero
</td>
<td>
Buscar oportunidades, ofrecer servicios de logística/material
</td>
<td>
Clubes/equipos que necesiten soporte de material
</td>
<td>
Perfil profesional, disponibilidad
</td>
<td>
Club, Equipo
</td>
</tr>
<tr>
<td>
Otros profesionales de apoyo (nutricionista, psicólogo deportivo, etc.)
</td>
<td>
Buscar oportunidades, ofrecer servicios especializados
</td>
<td>
Deportistas/clubes que requieran su especialidad
</td>
<td>
Perfil profesional, especialidad, disponibilidad
</td>
<td>
Jugador, Club, Equipo
</td>
</tr>
</table>

<callout icon="⚠️" color="orange_bg">
Pendiente (no incluido aquí, corresponde a Etapas 10-12): atributos/datos completos de cada actor, mapeo formal de relaciones con cardinalidad, y reglas de permisos/visibilidad (especialmente para menores y ubicación).
</callout>

#

6. Perfil como núcleo del sistema

El perfil no es solo una ficha pública; es una fuente principal de <b>contexto operativo</b>. El sistema debe distinguir:

```txt
QUIÉN SOY + QUÉ HAGO + DÓNDE ESTOY + CON QUIÉN ESTOY RELACIONADO
+ QUÉ NECESITO + QUÉ PUEDO OFRECER + QUÉ BUSCO
```

#

7. Club actual del jugador

<callout icon="📌">
Regla fijada: cuando aplique, el jugador debe tener registrado el club al que pertenece.
</callout>

No basta con Jugador + Edad + Posición. Debe existir:

```txt
Jugador → Club actual → Categoría → Competición → Temporada/contexto
```

Esto permite a los agentes comprender mejor trayectoria, nivel contextual, competición, categoría, relaciones y oportunidades.

<callout icon="⚠️" color="orange_bg">
Corrección del usuario (constatada y aplicada): esta regla es <b>condicional</b>, no universal. No se debe asumir que todo usuario de la plataforma ha jugado fútbol antes. El flujo correcto es: al crear su perfil, el jugador declara si ha jugado fútbol antes / tiene o tuvo club. Solo si responde que sí, el sistema exige club actual, categoría, competición, temporada y activa el historial de clubes (tipo CV deportivo). Si responde que no, su perfil es de iniciación y esos campos no se muestran ni se exigen. "Jugador (con club)" en las matrices de este documento debe leerse como el <b>estado resultante</b> de esa declaración positiva, no como un tipo de perfil fijo elegido de entrada.
</callout>

#

8. Eliminación del campo "nivel"

<callout icon="🚫" color="red_bg">
Se elimina la clasificación subjetiva: Principiante / Intermedio / Competitivo / Avanzado, por ser demasiado ambigua.
</callout>

En su lugar, la estructura deportiva real determina el contexto mediante: <b>Competición + División + Categoría + Club + Temporada + otros datos relevantes</b>.

#

9. Información detallada de cada entidad

Se requiere una representación rica de cada actor, no una ficha mínima.

<columns>
<column ratio="50">
<b>Club</b>

- Nombre, ubicación
- Competición, categorías, divisiones
- Equipos, temporadas
- Entrenamientos, tryouts
- Precios, horarios, contacto
- Servicios, staff
</column>
<column ratio="50">
<b>Jugador</b>

- Identidad, edad, posición
- Club actual, categoría, competición
- Trayectoria, oportunidades
- Disponibilidad
- Ubicación/contexto geográfico protegido
</column>
</columns>

<i>Los campos exactos se terminarán de definir en las matrices de actores/datos.</i>

## Matriz de Información / Datos por entidad (Etapa 10 — completa)

<callout icon="✅" color="green_bg">
Cierre de Etapa 10. Define, por entidad: atributos obligatorios, atributos opcionales, relaciones clave, y sensibilidad/fuente de actualización. El mapeo formal con cardinalidad (Etapa 11) y las reglas de permisos/visibilidad (Etapa 12) se construyen a partir de esta base.
</callout>

<table>
<tr>
<td>
Entidad
</td>
<td>
Atributos obligatorios
</td>
<td>
Atributos opcionales
</td>
<td>
Relaciones clave
</td>
<td>
Sensibilidad / fuente
</td>
</tr>
<tr>
<td>
Jugador (con club)
</td>
<td>
Nombre, fecha de nacimiento, posición, ubicación (protegida); club actual, historial de clubes, categoría, competición y temporada son obligatorios <b>únicamente si el jugador declaró haber jugado fútbol antes / tener o haber tenido club</b> (ver sección 7); si declara no tener experiencia previa, estos campos no se solicitan
</td>
<td>
Estatura/peso, pie dominante, videos/highlights, disponibilidad, redes sociales
</td>
<td>
Club actual, Familia (si menor), Scout, Entrenador, Preparador físico, Fisioterapeuta
</td>
<td>
Alta si es menor (ubicación ofuscada, requiere autorización familiar); dato ingresado por usuario/tutor
</td>
</tr>
<tr>
<td>
Niño / joven (sin club)
</td>
<td>
Nombre, edad, ubicación (protegida), tutor/familia vinculada
</td>
<td>
Posición de interés, experiencia previa, disponibilidad horaria
</td>
<td>
Familia (obligatoria), Academia/Club de interés
</td>
<td>
Muy alta (menor): consentimiento parental obligatorio, ubicación siempre ofuscada
</td>
</tr>
<tr>
<td>
Familia / Representante
</td>
<td>
Nombre, relación con el menor, contacto, ubicación
</td>
<td>
Presupuesto, preferencias de horario/distancia
</td>
<td>
Niño/joven (uno o más), Club, Academia
</td>
<td>
Alta (datos de contacto y del menor); dato ingresado por usuario
</td>
</tr>
<tr>
<td>
Club
</td>
<td>
Nombre, ubicación, competición(es), categorías, divisiones, temporada activa
</td>
<td>
Precios, horarios, servicios, staff, historial, redes sociales, instalaciones
</td>
<td>
Jugadores, Equipos, Staff, Academia (si aplica), Competición
</td>
<td>
Baja (dato institucional público); actualización periódica por el club o investigación dirigida
</td>
</tr>
<tr>
<td>
Academia
</td>
<td>
Nombre, ubicación, programas/categorías por edad, precios, horarios
</td>
<td>
Staff, instalaciones, tryouts de acceso, historial
</td>
<td>
Niño/joven, Familia, Jugador, Entrenador
</td>
<td>
Baja; actualización periódica por la academia
</td>
</tr>
<tr>
<td>
Equipo
</td>
<td>
Club al que pertenece, categoría, competición, temporada
</td>
<td>
Plantilla, necesidades puntuales, resultados
</td>
<td>
Club (padre), Jugadores, Entrenador, Staff
</td>
<td>
Baja; deriva del club
</td>
</tr>
<tr>
<td>
Scout
</td>
<td>
Nombre, club/organización (si aplica), zona de cobertura
</td>
<td>
Especialización (posición/categoría), historial de reportes
</td>
<td>
Jugador, Club
</td>
<td>
Media (acceso a datos de jugadores, incl. menores)
</td>
</tr>
<tr>
<td>
Entrenador
</td>
<td>
Nombre, certificaciones, ubicación, disponibilidad
</td>
<td>
Experiencia, historial de clubes/equipos, especialidad por categoría/edad
</td>
<td>
Club, Academia, Equipo, Jugador
</td>
<td>
Media; dato ingresado por usuario, verificable
</td>
</tr>
<tr>
<td>
Preparador físico
</td>
<td>
Nombre, certificación, ubicación, disponibilidad
</td>
<td>
Especialidad, experiencia, historial
</td>
<td>
Jugador, Club, Equipo
</td>
<td>
Media; dato ingresado por usuario
</td>
</tr>
<tr>
<td>
Fisioterapeuta
</td>
<td>
Nombre, certificación/licencia, ubicación, disponibilidad
</td>
<td>
Especialidad, experiencia, historial
</td>
<td>
Jugador, Club, Equipo
</td>
<td>
Media; licencia idealmente verificable
</td>
</tr>
<tr>
<td>
Asistente
</td>
<td>
Nombre, rol/función, ubicación, disponibilidad
</td>
<td>
Experiencia, historial
</td>
<td>
Club, Staff, Equipo
</td>
<td>
Baja-Media
</td>
</tr>
<tr>
<td>
Staff (genérico)
</td>
<td>
Nombre, función, club/equipo vinculado
</td>
<td>
Experiencia, disponibilidad
</td>
<td>
Club, Equipo
</td>
<td>
Baja
</td>
</tr>
<tr>
<td>
Utillero
</td>
<td>
Nombre, ubicación, disponibilidad
</td>
<td>
Experiencia, especialidad de material
</td>
<td>
Club, Equipo
</td>
<td>
Baja
</td>
</tr>
<tr>
<td>
Otros profesionales de apoyo
</td>
<td>
Nombre, especialidad, ubicación, disponibilidad
</td>
<td>
Certificaciones, experiencia
</td>
<td>
Jugador, Club, Equipo
</td>
<td>
Media
</td>
</tr>
</table>

### Entidades de soporte (no son actores, pero sostienen sus atributos)

<table>
<tr>
<td>
Entidad
</td>
<td>
Atributos
</td>
<td>
Relación con
</td>
</tr>
<tr>
<td>
Competición
</td>
<td>
Nombre, tipo (liga/torneo/copa), divisiones, temporadas
</td>
<td>
Club, Equipo, Categoría
</td>
</tr>
<tr>
<td>
Categoría / División
</td>
<td>
Nombre, rango de edad, nivel
</td>
<td>
Competición, Club, Equipo, Jugador
</td>
</tr>
<tr>
<td>
Temporada
</td>
<td>
Año/ciclo, fecha inicio/fin
</td>
<td>
Competición, Club, Equipo, Jugador
</td>
</tr>
<tr>
<td>
Tryout
</td>
<td>
Fecha, ubicación, categoría, requisitos, cupo
</td>
<td>
Club, Academia, Jugador, Niño/joven
</td>
</tr>
<tr>
<td>
Oportunidad
</td>
<td>
Tipo (jugador/staff), requisitos, ubicación, fecha límite
</td>
<td>
Club, Jugador, Entrenador, Preparador físico, Fisioterapeuta
</td>
</tr>
<tr>
<td>
Filial / Rama de Club (multi-competición)
</td>
<td>
Nombre de la filial, club matriz, competición/federación a la que está afiliada, categoría, temporada
</td>
<td>
Club (matriz), Competición, Equipo, Jugador
</td>
</tr>
</table>

<callout icon="⚠️" color="orange_bg">
Pendiente (Etapa 12): reglas de quién puede ver/editar cada atributo, especialmente ubicación y datos de menores. La cardinalidad de relaciones (Etapa 11) se cierra a continuación.
</callout>

## Matriz de Relaciones (Etapa 11 — completa)

<callout icon="✅" color="green_bg">
Cierre de Etapa 11. Mapeo formal con cardinalidad, construido directamente sobre la Matriz de Actores (Etapa 9) y la Matriz de Datos (Etapa 10) — no requirió nueva investigación, solo formalizar lo ya definido.
</callout>

<table>
<tr>
<td>
Relación
</td>
<td>
Cardinalidad
</td>
<td>
Regla / nota
</td>
</tr>
<tr>
<td>
Jugador — Club actual
</td>
<td>
N:1 por competición (excepción: N:M entre competiciones distintas)
</td>
<td>
Un jugador tiene máximo un club/filial activo por competición y temporada; puede tener más de un club/filial simultáneo solo si cada uno pertenece a una competición/federación distinta y se respetan las normas FIFA y de cada asociación sobre doble registro (ver relación Jugador — Filial)
</td>
</tr>
<tr>
<td>
Jugador — Familia/Representante
</td>
<td>
M:N
</td>
<td>
Un jugador/niño menor puede tener 1+ representantes; un representante puede tener 1+ jugadores a cargo (hermanos)
</td>
</tr>
<tr>
<td>
Jugador — Competición
</td>
<td>
N:1 (derivada)
</td>
<td>
No se almacena directo; se resuelve vía Club → Competición
</td>
</tr>
<tr>
<td>
Jugador — Categoría
</td>
<td>
N:1 (derivada)
</td>
<td>
Se resuelve vía Club/Equipo, no se duplica el dato
</td>
</tr>
<tr>
<td>
Club — Competición
</td>
<td>
N:M
</td>
<td>
Un club puede competir en varias competiciones/categorías; una competición agrupa muchos clubes
</td>
</tr>
<tr>
<td>
Club — Categoría/División
</td>
<td>
1:N
</td>
<td>
Un club gestiona varias categorías simultáneamente
</td>
</tr>
<tr>
<td>
Club — Equipo
</td>
<td>
1:N
</td>
<td>
Un club tiene varios equipos, uno por categoría/temporada
</td>
</tr>
<tr>
<td>
Club — Filial (rama multi-competición)
</td>
<td>
1:N
</td>
<td>
Un club (marca/institución) puede tener varias filiales o ramas, cada una registrada en una competición/federación distinta (ej. equipo principal en Liga FUTVE, cantera en Liga FUTVE Junior, filial formativa en Liga Pipo Rossi, segundo equipo/reserva en torneos de la asociación regional)
</td>
</tr>
<tr>
<td>
Filial — Competición
</td>
<td>
N:1
</td>
<td>
Cada filial se afilia formalmente a una única competición/federación por temporada
</td>
</tr>
<tr>
<td>
Filial — Equipo
</td>
<td>
1:N
</td>
<td>
Cada filial puede tener uno o varios equipos por categoría/temporada dentro de su competición
</td>
</tr>
<tr>
<td>
Jugador — Filial
</td>
<td>
N:M (excepción controlada)
</td>
<td>
Un jugador normalmente pertenece a una sola filial; puede estar registrado en dos filiales/competiciones simultáneas solo si las normas FIFA y de cada asociación lo permiten (doble registro). No asumir por defecto: se valida caso por caso según el reglamento de cada competición
</td>
</tr>
<tr>
<td>
Equipo — Jugador
</td>
<td>
1:N
</td>
<td>
Un equipo agrupa varios jugadores por temporada
</td>
</tr>
<tr>
<td>
Club — Staff / Entrenador / Prep. físico / Fisio / Asistente / Utillero
</td>
<td>
N:M
</td>
<td>
Un profesional puede vincularse a varios clubes (histórico o simultáneo); un club tiene varios profesionales
</td>
</tr>
<tr>
<td>
Profesional — Jugador
</td>
<td>
N:M
</td>
<td>
Ej. un preparador físico atiende varios jugadores; un jugador puede tener varios profesionales
</td>
</tr>
<tr>
<td>
Scout — Jugador
</td>
<td>
N:M
</td>
<td>
Relación de seguimiento/watchlist; un scout sigue muchos jugadores, un jugador puede ser seguido por muchos scouts
</td>
</tr>
<tr>
<td>
Scout — Club
</td>
<td>
N:1 (opcional)
</td>
<td>
Un scout puede estar afiliado a un club o operar independiente (0:1)
</td>
</tr>
<tr>
<td>
Academia — Niño/Joven / Jugador
</td>
<td>
1:N
</td>
<td>
Una academia forma a muchos niños/jugadores
</td>
</tr>
<tr>
<td>
Academia — Entrenador
</td>
<td>
N:M
</td>
<td>
Un entrenador puede trabajar para varias academias
</td>
</tr>
<tr>
<td>
Club/Academia — Tryout
</td>
<td>
1:N
</td>
<td>
Cada club/academia puede publicar varios tryouts
</td>
</tr>
<tr>
<td>
Jugador/Niño — Tryout
</td>
<td>
N:M
</td>
<td>
Un jugador se postula a varios tryouts; un tryout recibe varios postulantes
</td>
</tr>
<tr>
<td>
Club — Oportunidad
</td>
<td>
1:N
</td>
<td>
Un club publica varias oportunidades (jugador o staff)
</td>
</tr>
<tr>
<td>
Oportunidad — Jugador/Profesional
</td>
<td>
N:M
</td>
<td>
Postulaciones; una oportunidad recibe varios postulantes y un actor se postula a varias oportunidades
</td>
</tr>
<tr>
<td>
Competición — Temporada
</td>
<td>
1:N
</td>
<td>
Cada competición se repite a lo largo de varias temporadas
</td>
</tr>
<tr>
<td>
Jugador — Club (relación espacial)
</td>
<td>
N:N calculada
</td>
<td>
No se almacena: distancia/tiempo de viaje calculado en tiempo real por el Agente 3 (Fricción Espacial) de la capa Geo, para cada par jugador-club candidato
</td>
</tr>
</table>

<callout icon="🧭" color="yellow_bg">
Ejemplo real verificado (corrección tras constatar la información): <b>Metropolitanos FC</b> tiene su primer equipo en la Liga FUTVE (Primera División de Venezuela), su cantera "Metropolitanos FC Cantera" en la Liga FUTVE Junior, y una filial formativa "MetroAEF" —en alianza con la <b>Academia Euroamericana de Fútbol (AEF)</b>, una academia privada, que no debe confundirse con la Asociación de Fútbol del Distrito Capital— compitiendo en la <b>Liga Pipo Rossi</b> en categorías sub-13 a sub-19. Adicionalmente, su segundo equipo/reserva ha competido en la Tercera División de Venezuela y en torneos de la Asociación de Fútbol del Distrito Capital. Es decir: un mismo club puede tener 3-4 filiales activas a la vez, cada una en una competición distinta. El modelo distingue Club (marca/institución) de Filial (registro específico por competición), en vez de asumir un solo club = una sola competición.
</callout>

## Auditoría y potenciación transversal (Etapas 1-11)

<callout icon="🔍" color="blue_bg">
Ejercicio solicitado: auditar y potenciar todo lo construido hasta ahora, aplicando de forma adaptable distintos agentes según la naturaleza del hallazgo (Nivel 2 de adaptabilidad definido en la sección 21: el sistema elige el agente/proceso según el contexto, no uno fijo para todo).
</callout>

### Hallazgo crítico (Auditor QA, freno "no inventar datos") — resuelto

<callout icon="✅" color="green_bg">
Inconsistencia detectada originalmente: la tabla de madurez (sección 33) marcaba <b>Matriz de Contexto, Casos, Necesidades y Matching en 100%</b>, pero su contenido tabular original no estaba recuperado en este documento. <b>Resuelto en esta sesión:</b> las cuatro matrices fueron reconstruidas con tablas completas (sección 11-14), derivadas directamente de Actores (Etapa 9) y Datos (Etapa 10), sin inventar información nueva. Se retiran los asteriscos de la tabla de madurez.
</callout>

### Refuerzos aplicados por etapa (Analista de Viabilidad + Arquitecto de Ecosistema + Agentes Geo)

<table>
<tr>
<td>
Etapa
</td>
<td>
Hallazgo
</td>
<td>
Refuerzo aplicado
</td>
</tr>
<tr>
<td>
Etapa 3/9 — Actores
</td>
<td>
Faltaba formalizar que una Familia puede tener varios jugadores a cargo (hermanos) y un jugador varios representantes
</td>
<td>
Cardinalidad M:N formalizada en la nueva Matriz de Relaciones
</td>
</tr>
<tr>
<td>
Etapas 4-7 — Contexto, Casos, Necesidades, Matching
</td>
<td>
Madurez marcada 100% pero tabla original no recuperada (ver hallazgo crítico arriba)
</td>
<td>
Reconstruidas con tablas completas en esta sesión, usando Actores + Datos + Relaciones como insumo directo; asteriscos retirados de la tabla de madurez
</td>
</tr>
<tr>
<td>
Etapa 8 — Geo (Fricción Espacial / Geo-Matching)
</td>
<td>
La relación espacial Jugador—Club que alimenta al Agente 3 y Agente 4 de Geo no estaba formalizada como relación del modelo de datos
</td>
<td>
Agregada como relación calculada N:N en la Matriz de Relaciones (no se almacena, se computa en tiempo real)
</td>
</tr>
<tr>
<td>
Etapa 10 — Datos
</td>
<td>
Scout—Club estaba implícito en atributos ("club/organización si aplica") pero no como relación explícita
</td>
<td>
Formalizada como relación N:1 opcional en la Matriz de Relaciones
</td>
</tr>
<tr>
<td>
Etapa 11 — Relaciones (esta etapa)
</td>
<td>
Sin precedente que auditar (recién construida)
</td>
<td>
Construida directamente sobre Actores + Datos, sin inventar nuevos actores ni atributos
</td>
</tr>
</table>

<callout icon="💡" color="purple_bg">
Conclusión de la auditoría: el modelo de Actores, Datos, Relaciones y ahora Contexto/Casos/Necesidades/Matching es internamente consistente y sostiene ya el trabajo de Permisos (Etapa 12) y los primeros Flujos (Etapa 13). El riesgo de brecha entre "madurez declarada" y "contenido recuperado" en las Etapas 4-7 quedó resuelto en esta misma sesión.
</callout>

## Matriz de Permisos y Visibilidad (Etapa 12 — completa)

<callout icon="✅" color="green_bg">
Cierre de Etapa 12. Construida sobre Actores (Etapa 9), Datos (Etapa 10) y Relaciones (Etapa 11): define quién ve, edita, publica y autoriza cada tipo de información, con énfasis en menores, ubicación y datos de contacto.
</callout>

### Visibilidad y edición de perfiles entre actores

<table>
<tr>
<td>
Actor propietario del dato
</td>
<td>
Quién ve el perfil completo
</td>
<td>
Quién ve solo resumen público
</td>
<td>
Quién puede editar
</td>
<td>
Autorización requerida
</td>
</tr>
<tr>
<td>
Jugador (mayor de edad, con club)
</td>
<td>
El propio jugador; su club actual/filial
</td>
<td>
Scouts, otros clubes/academias (posición, categoría, club actual, sin contacto directo)
</td>
<td>
Solo el propio jugador
</td>
<td>
Ninguna adicional (dato de adulto, consentimiento implícito al crear perfil)
</td>
</tr>
<tr>
<td>
Niño / joven (menor de edad)
</td>
<td>
Familia/tutor; el propio menor (vista acompañada)
</td>
<td>
Academias/Clubes de interés: solo resumen anonimizado (edad, zona amplia, interés) hasta autorización explícita
</td>
<td>
Familia/tutor únicamente; el menor no gestiona permisos por sí mismo
</td>
<td>
Consentimiento parental obligatorio para crear perfil, hacerlo visible a terceros, o habilitar contacto
</td>
</tr>
<tr>
<td>
Familia / Representante
</td>
<td>
El propio representante
</td>
<td>
Club/Academia con quien haya interés mutuo (solo datos de contacto tras aceptar)
</td>
<td>
Solo el propio representante
</td>
<td>
Ninguna adicional; es quien autoriza, no quien requiere autorización
</td>
</tr>
<tr>
<td>
Club / Academia
</td>
<td>
Público en general (info institucional: nombre, ubicación, categorías, precios, filiales)
</td>
<td>
(No aplica distinción: la info institucional básica es siempre pública)
</td>
<td>
Administrador(es) designado(s) del club/academia
</td>
<td>
Ninguna para info institucional; sí se requiere verificación de identidad institucional al crear la cuenta
</td>
</tr>
<tr>
<td>
Scout
</td>
<td>
Club(es) con quien colabora activamente
</td>
<td>
Otros scouts/clubes ven solo que existe (sin acceso a watchlists/reportes ajenos)
</td>
<td>
Solo el propio scout
</td>
<td>
Ninguna para su propio perfil; sí la necesita para acceder a datos de menores (ver regla especial)
</td>
</tr>
<tr>
<td>
Entrenador / Prep. físico / Fisioterapeuta / Asistente / Staff / Utillero / Otros profesionales
</td>
<td>
El propio profesional; clubes/academias con quienes tiene vínculo activo
</td>
<td>
Público: perfil profesional (especialidad, certificación, disponibilidad) sin datos de contacto directo
</td>
<td>
Solo el propio profesional
</td>
<td>
Ninguna adicional; certificaciones se marcan verificado/no verificado (Etapa 10)
</td>
</tr>
</table>

### Reglas especiales sobre datos sensibles

<table>
<tr>
<td>
Dato sensible
</td>
<td>
Regla de visibilidad
</td>
</tr>
<tr>
<td>
Ubicación de menores
</td>
<td>
Nunca exacta ni pública; siempre ofuscada a nivel de zona/radio. Solo la familia ve la ubicación precisa
</td>
</tr>
<tr>
<td>
Ubicación de adultos
</td>
<td>
Exacta solo visible al propio usuario; visible en forma aproximada (radio/distancia calculada por el Agente 3 de Geo) a clubes/scouts/academias; nunca expuesta como dirección pública en el perfil
</td>
</tr>
<tr>
<td>
Datos generales de menores (perfil, categoría, interés)
</td>
<td>
Requieren consentimiento parental explícito para: crear el perfil, hacerlo visible a terceros, y habilitar contacto directo. La familia puede revocar la visibilidad en cualquier momento
</td>
</tr>
<tr>
<td>
Contacto directo (teléfono, email, redes)
</td>
<td>
Oculto por defecto para todos los actores; se revela únicamente cuando ambas partes aceptan iniciar contacto (opt-in mutuo), nunca de forma automática tras un match
</td>
</tr>
<tr>
<td>
Club actual / historial de clubes
</td>
<td>
Visible según nivel de confianza ("verificado" vía COMET u otra fuente oficial, o "declarado" por el usuario/club); no se expone la fuente o credenciales de verificación en sí, solo la etiqueta de confianza
</td>
</tr>
<tr>
<td>
Certificaciones profesionales
</td>
<td>
Visibles como "verificado" / "no verificado" en el perfil público; el documento/licencia original nunca se publica, solo se usa para el proceso interno de verificación
</td>
</tr>
<tr>
<td>
Reportes y watchlists de Scouting
</td>
<td>
Privados del scout/club que los genera; nunca visibles al jugador evaluado ni a otros scouts/clubes
</td>
</tr>
</table>

### Quién puede publicar qué

<table>
<tr>
<td>
Actor
</td>
<td>
Puede publicar
</td>
<td>
No puede publicar
</td>
</tr>
<tr>
<td>
Club / Academia
</td>
<td>
Tryouts, oportunidades (jugador o staff), información institucional
</td>
<td>
Perfiles de jugadores/profesionales que no sean de su plantilla
</td>
</tr>
<tr>
<td>
Jugador / Profesional
</td>
<td>
Su propio perfil, disponibilidad, trayectoria
</td>
<td>
Oportunidades/tryouts formales (reservado a instituciones)
</td>
</tr>
<tr>
<td>
Familia
</td>
<td>
Perfil del menor a su cargo, con control total de visibilidad
</td>
<td>
Perfiles de otros menores que no estén bajo su representación
</td>
</tr>
<tr>
<td>
Scout
</td>
<td>
Reportes/watchlists internos (no públicos)
</td>
<td>
Contenido público general, tryouts u oportunidades
</td>
</tr>
</table>

## Flujos de Experiencia (Etapa 13 — completa, casos críticos)

<callout icon="✅" color="green_bg">
Cierre de Etapa 13. Cuatro flujos críticos bocetados y validados contra la Matriz de Casos (Etapa 5), aplicando Contexto (Etapa 4), Datos (Etapa 10), Relaciones (Etapa 11), Permisos (Etapa 12) y Matching (Etapa 7) ya cerrados. Cumple el mínimo de 3 flujos del checklist "Gate to Phase 2".
</callout>

### Flujo 1 — Jugador con club busca cambio de club

```txt
Perfil Jugador (club actual, categoría, competición)
        ↓
Contexto: jugador activo evaluando cambio (Matriz de Contexto)
        ↓
Matching Jugador—Club/Filial (Etapa 7): filtra por posición/categoría/competición compatible
        ↓
Agente 3 (Fricción Espacial): tiempo de viaje real a cada candidato
        ↓
Agente 4 (Geo-Matching): cruza estructura deportiva + tiempo de viaje + fecha límite
        ↓
Permisos (Etapa 12): clubes ven solo resumen público hasta opt-in del jugador
        ↓
Recomendaciones priorizadas de clubes/filiales, con justificación
```

### Flujo 2 — Niño/joven sin experiencia (iniciación)

```txt
Familia crea perfil del menor (consentimiento parental obligatorio)
        ↓
Contexto: interés en iniciación, ubicación ofuscada (Matriz de Contexto)
        ↓
Agente 1 (Privacidad de Contexto): ofusca ubicación antes de cualquier cálculo geo
        ↓
Matching Jugador/Niño—Academia (Etapa 7): filtra por edad, ubicación, precio, cupo
        ↓
Agente 2 (Descubrimiento) + Agente 3 (Fricción Espacial): localizan y puntúan opciones
        ↓
Comparativo priorizado de academias/clubes de iniciación, visible solo a la familia
```

### Flujo 3 — Club/Filial busca jugador

```txt
Club/Filial publica necesidad (posición, categoría, competición específica)
        ↓
Se registra como Oportunidad (entidad de soporte, Etapa 10)
        ↓
Matching Jugador—Club (Etapa 7): filtra candidatos compatibles dentro/fuera del club
        ↓
Verificación de contexto: club actual/historial con etiqueta verificado (COMET) o declarado
        ↓
Agentes 3/4 Geo: viabilidad real de traslado del candidato
        ↓
Permisos (Etapa 12): club ve solo resumen público de candidatos ajenos hasta contacto formal
        ↓
Lista priorizada de candidatos con justificación y nivel de confianza del dato
```

### Flujo 4 — Profesional (Entrenador / Prep. físico / Fisioterapeuta) busca oportunidad

```txt
Profesional crea/actualiza perfil (certificación, especialidad, disponibilidad, ubicación)
        ↓
Contexto: profesional en búsqueda activa (Matriz de Contexto)
        ↓
Matching Club—Profesional (Etapa 7): cruza vacantes abiertas con su especialidad
        ↓
Certificación marcada verificado/no verificado (Etapas 10 y 12)
        ↓
Agente 3 (Fricción Espacial): distancia/tiempo de traslado
        ↓
Lista priorizada de oportunidades compatibles; contacto habilitado solo por opt-in mutuo
```

<callout icon="💡" color="purple_bg">
Los cuatro flujos comparten el mismo patrón: Perfil → Contexto → Matching → Geo (cuando aplica) → Permisos → Resultado priorizado, confirmando que la columna vertebral conceptual (sección 15) es consistente en la práctica, no solo en el diagrama abstracto.
</callout>

## Arquitectura Conceptual (Etapa 14 — completa)

<callout icon="✅" color="green_bg">
Cierre de Etapa 14, último requisito del checklist "Gate to Phase 2". Formaliza en capas la cadena Usuarios → Perfiles → Contexto → Datos → Agentes → Matching → Recomendaciones → Acciones, ya validada en la práctica por los 4 flujos de la Etapa 13.
</callout>

<table>
<tr>
<td>
Capa
</td>
<td>
Qué contiene
</td>
<td>
Etapa que la sustenta
</td>
<td>
Ejemplo concreto ya construido
</td>
</tr>
<tr>
<td>
1. Usuarios
</td>
<td>
Los actores del ecosistema y sus roles
</td>
<td>
Actores/Roles (Etapa 9)
</td>
<td>
Jugador, Niño/joven, Familia, Club, Academia, Scout, Entrenador, Prep. físico, Fisioterapeuta, Staff, etc.
</td>
</tr>
<tr>
<td>
2. Perfiles
</td>
<td>
La representación estructurada de cada actor, con visibilidad diferenciada
</td>
<td>
Información/Datos (Etapa 10) + Permisos/Visibilidad (Etapa 12)
</td>
<td>
Perfil de Jugador con club actual, categoría, competición; resumen público vs. perfil completo según quien consulte
</td>
</tr>
<tr>
<td>
3. Contexto
</td>
<td>
Situación, atributos, relaciones activas y ubicación/condiciones de cada actor en un momento dado
</td>
<td>
Matriz de Contexto (Etapa 4) + Relaciones (Etapa 11)
</td>
<td>
"Jugador activo evaluando cambio de club"; "Niño interesado en iniciación, sin trayectoria formal"
</td>
</tr>
<tr>
<td>
4. Datos
</td>
<td>
Entidades, atributos y relaciones formales que sostienen el contexto, incluyendo fuentes externas etiquetadas por nivel de confianza
</td>
<td>
Información/Datos (Etapa 10) + Relaciones (Etapa 11) + Fuentes externas COMET
</td>
<td>
Club actual "verificado" (vía COMET) vs. "declarado"; historial de clubes obligatorio
</td>
</tr>
<tr>
<td>
5. Agentes
</td>
<td>
Orquestación especializada que procesa contexto y datos según el caso
</td>
<td>
Geo-inteligencia (Etapa 8) + Arquitectura de agentes (sección 16-22)
</td>
<td>
Agente 1 Privacidad de Contexto, Agente 2 Descubrimiento, Agente 3 Fricción Espacial, Agente 4 Geo-Matching
</td>
</tr>
<tr>
<td>
6. Matching
</td>
<td>
Reglas de compatibilidad específicas por cada par de actores
</td>
<td>
Matriz de Matching (Etapa 7)
</td>
<td>
Jugador—Club, Jugador—Academia, Jugador/Niño—Tryout, Club—Profesional, Scout—Jugador, Jugador/Profesional—Oportunidad
</td>
</tr>
<tr>
<td>
7. Recomendaciones
</td>
<td>
Salida priorizada y justificada del matching, nunca una lista sin criterio
</td>
<td>
Matriz de Matching (Etapa 7) + Flujos de Experiencia (Etapa 13)
</td>
<td>
Lista de clubes/academias/oportunidades ordenada por fricción espacial y compatibilidad de categoría
</td>
</tr>
<tr>
<td>
8. Acciones
</td>
<td>
Lo que el usuario puede hacer con la recomendación, sujeto a reglas de publicación y contacto
</td>
<td>
Permisos/Visibilidad (Etapa 12), "Quién puede publicar qué"
</td>
<td>
Iniciar contacto (opt-in mutuo), postularse a tryout, publicar oportunidad/tryout
</td>
</tr>
</table>

```txt
USUARIOS → PERFILES → CONTEXTO → DATOS → AGENTES → MATCHING → RECOMENDACIONES → ACCIONES
                    ↑__________________________________________________________________|
                              (seguimiento retroalimenta el contexto)

Envoltura transversal en las 8 capas: Privacidad + Permisos + Geolocalización + Calidad de datos
```

<callout icon="💡" color="purple_bg">
Esta arquitectura no es un diagrama nuevo: es la formalización en capas de la columna vertebral conceptual (sección 15) y del modelo del motor (sección 24), ya recorrida punta a punta por los 4 flujos de la Etapa 13. Con su cierre, el checklist "Gate to Phase 2" queda completo: la Etapa 15 (Definición del MVP) puede abrirse formalmente.
</callout>

## Definición del MVP (Etapa 15 — completa)

<callout icon="✅" color="green_bg">
Cierre de Etapa 15. Define qué entra, qué no, y qué debe funcionar primero, aplicando el freno de la sección 32: "no construir funciones porque podemos, construir capacidades porque resuelven necesidades". Alcance elegido por cobertura de Casos (Etapa 5) con la menor complejidad de Agentes/Permisos posible.
</callout>

### Alcance de actores en el MVP

<table>
<tr>
<td>
Actor
</td>
<td>
¿En el MVP?
</td>
<td>
Motivo
</td>
</tr>
<tr>
<td>
Jugador (con club)
</td>
<td>
Sí
</td>
<td>
Cubre el caso más frecuente (cambio de club) y valida el ciclo completo Perfil→Recomendación
</td>
</tr>
<tr>
<td>
Niño / joven + Familia
</td>
<td>
Sí
</td>
<td>
Cubre el caso de iniciación y obliga a construir Permisos de menores desde el día uno (no se puede posponer sin riesgo)
</td>
</tr>
<tr>
<td>
Club / Academia
</td>
<td>
Sí
</td>
<td>
Sin oferta (clubes/academias) no hay qué recomendar; ambos lados del match son obligatorios
</td>
</tr>
<tr>
<td>
Scout
</td>
<td>
Sí <span color="orange">(corrección del usuario: todos los actores del ecosistema deben estar en la plataforma desde el MVP)</span>
</td>
<td>
Estaba diferido a Fase 2 por baja criticidad frente al match Jugador↔Club/Academia, pero el usuario fijó que ningún actor documentado queda fuera de la plataforma; se incluye desde el lanzamiento, con alcance funcional inicial simplificado
</td>
</tr>
<tr>
<td>
Entrenador / Prep. físico / Fisioterapeuta / Asistente / Staff / Utillero / Otros profesionales
</td>
<td>
Sí <span color="orange">(corrección del usuario: todos los actores del ecosistema deben estar en la plataforma desde el MVP)</span>
</td>
<td>
Estaban diferidos a Fase 2 por ser secundarios frente al match Jugador↔Club/Academia, pero el usuario fijó que ningún actor documentado queda fuera de la plataforma; se incluyen desde el lanzamiento, con alcance funcional inicial simplificado
</td>
</tr>
</table>

### Alcance por capa de la Arquitectura Conceptual (Etapa 14)

<table>
<tr>
<td>
Capa
</td>
<td>
En el MVP
</td>
<td>
Simplificado o diferido a Fase 2
</td>
</tr>
<tr>
<td>
Perfiles
</td>
<td>
Atributos obligatorios de Jugador, Niño, Familia, Club, Academia (Etapa 10)
</td>
<td>
Atributos opcionales (videos/highlights, redes sociales, instalaciones) diferidos
</td>
</tr>
<tr>
<td>
Contexto
</td>
<td>
Situación básica (activo con club / interesado en iniciación) y ubicación
</td>
<td>
Contexto fino de Scout/Profesionales diferido junto con esos actores
</td>
</tr>
<tr>
<td>
Datos
</td>
<td>
Entidades núcleo: Jugador, Club, Academia, Familia, Competición, Categoría, Temporada
</td>
<td>
Filial multi-competición, verificación COMET y demás datos del backlog de acceso externo (sección 35) quedan fuera
</td>
</tr>
<tr>
<td>
Agentes (Geo)
</td>
<td>
Agente 1 (Privacidad de Contexto, obligatorio) + Agente 3 (Fricción Espacial, versión simple: distancia/tiempo estimado)
</td>
<td>
Agente 2 (Descubrimiento con caché avanzado) y Agente 4 (Geo-Matching con estructura deportiva completa) en versión reducida; se refinan en Fase 2
</td>
</tr>
<tr>
<td>
Matching
</td>
<td>
Jugador—Club, Jugador/Niño—Academia
</td>
<td>
Scout—Jugador, Club—Profesional, Jugador/Profesional—Oportunidad diferidos con sus actores
</td>
</tr>
<tr>
<td>
Permisos
</td>
<td>
Reglas de menores (consentimiento parental, ubicación ofuscada) y contacto directo oculto por defecto (opt-in mutuo): no negociables desde el día uno
</td>
<td>
Etiqueta verificado/declarado vía COMET diferida (depende de acceso externo, sección 35)
</td>
</tr>
<tr>
<td>
Recomendaciones / Acciones
</td>
<td>
Lista priorizada + botón de "iniciar contacto" (opt-in mutuo)
</td>
<td>
Publicación de tryouts/oportunidades formales, reportes de scouting, diferidos
</td>
</tr>
</table>

### Orden de construcción (qué debe funcionar primero)

<table>
<tr>
<td>
Orden
</td>
<td>
Qué debe funcionar
</td>
<td>
Por qué va primero
</td>
</tr>
<tr>
<td>
1
</td>
<td>
Creación de perfil (Jugador, Niño/Familia, Club, Academia) con atributos obligatorios y permisos de menores activos desde el inicio
</td>
<td>
Sin perfil no hay contexto ni datos; los permisos de menores son un requisito legal/ético, no una mejora posterior
</td>
</tr>
<tr>
<td>
2
</td>
<td>
Contexto básico derivado del perfil (situación + ubicación)
</td>
<td>
Es el insumo directo del matching; no requiere agentes complejos todavía
</td>
</tr>
<tr>
<td>
3
</td>
<td>
Matching Jugador—Club y Jugador/Niño—Academia con Geo simplificado (Agente 1 + Agente 3 básico)
</td>
<td>
Es el corazón del producto; valida si el sistema realmente reduce fricción de búsqueda
</td>
</tr>
<tr>
<td>
4
</td>
<td>
Recomendación priorizada + acción de contacto (opt-in mutuo)
</td>
<td>
Cierra el ciclo Perfil→Contexto→Matching→Acción; sin esto el match no genera valor real
</td>
</tr>
<tr>
<td>
5
</td>
<td>
Flujo 1 (cambio de club) y Flujo 2 (iniciación) completos de punta a punta (Etapa 13)
</td>
<td>
Son los dos casos de mayor frecuencia esperada (Jugador con club, Niño sin experiencia); validan el MVP con usuarios reales
</td>
</tr>
</table>

<callout icon="⚠️" color="orange_bg">
<b>Corrección aplicada:</b> Scout y los profesionales de apoyo (Entrenador, Prep. físico, Fisioterapeuta, Asistente, Staff, Utillero) ya <b>no quedan fuera del MVP</b> — el usuario fijó que todos los actores documentados deben estar presentes en la plataforma desde el inicio. Sigue fuera del MVP: verificación vía COMET (bloqueada por acceso externo, sección 35); modelo de Filial multi-competición en la interfaz (el dato puede existir en el modelo pero no se activa su UI); reportes/analytics avanzados; publicación formal de tryouts/oportunidades. Esto pasa a Fase 2, después de validar el ciclo básico con datos reales (Etapa 21-22).
</callout>

## Priorización (Etapa 16 — completa)

<callout icon="✅" color="green_bg">
Cierre de Etapa 16. Prioriza cada Caso (Etapa 5) y capacidad de Agente/Geo ya definidos, según valor, dificultad, dependencia, riesgo, frecuencia e impacto, sin inventar capacidades nuevas.
</callout>

<table>
<tr>
<td>
#
</td>
<td>
Elemento
</td>
<td>
Prioridad
</td>
<td>
Justificación (valor / dificultad / dependencia / riesgo / frecuencia / impacto)
</td>
</tr>
<tr>
<td>
1
</td>
<td>
Perfil + Permisos de menores (creación segura)
</td>
<td>
Crítico
</td>
<td>
Valor y frecuencia máximos (todo usuario pasa por aquí); riesgo legal/ético alto si se omite; dependencia de todo lo demás
</td>
</tr>
<tr>
<td>
2
</td>
<td>
Contexto básico (situación + ubicación)
</td>
<td>
Crítico
</td>
<td>
Insumo directo del matching; dificultad baja; depende solo del perfil
</td>
</tr>
<tr>
<td>
3
</td>
<td>
Matching Jugador—Club (cambio de club)
</td>
<td>
Crítico
</td>
<td>
Máximo valor de negocio y frecuencia; valida el producto completo
</td>
</tr>
<tr>
<td>
4
</td>
<td>
Matching Jugador/Niño—Academia (iniciación)
</td>
<td>
Crítico
</td>
<td>
Cubre el segundo caso más frecuente; mismo nivel de urgencia que el anterior
</td>
</tr>
<tr>
<td>
5
</td>
<td>
Búsqueda de jugadores por perfil (lado Club)
</td>
<td>
Crítico
</td>
<td>
Sin esto el matching es unidireccional y no genera valor real para los clubes
</td>
</tr>
<tr>
<td>
6
</td>
<td>
Recomendación priorizada + contacto opt-in
</td>
<td>
Crítico
</td>
<td>
Cierra el ciclo Perfil→Acción; sin esto el match no produce resultado de negocio
</td>
</tr>
<tr>
<td>
7
</td>
<td>
Geo simplificado (Agente 1 + Agente 3 básico)
</td>
<td>
Crítico
</td>
<td>
Requerido para que el matching tenga sentido geográfico mínimo desde el lanzamiento
</td>
</tr>
<tr>
<td>
8
</td>
<td>
Postulación a tryout
</td>
<td>
Alto
</td>
<td>
Alta frecuencia esperada; dificultad media; depende del matching ya construido
</td>
</tr>
<tr>
<td>
9
</td>
<td>
Selección de academia por familia (comparativo)
</td>
<td>
Alto
</td>
<td>
Valor incremental sobre el matching de iniciación ya priorizado como crítico
</td>
</tr>
<tr>
<td>
10
</td>
<td>
Geo avanzado (Agente 2 Descubrimiento con caché, Agente 4 Geo-Matching completo)
</td>
<td>
Alto
</td>
<td>
Mejora sustancialmente la calidad de la recomendación, pero no bloquea el lanzamiento inicial
</td>
</tr>
<tr>
<td>
11
</td>
<td>
Publicación de tryout (por Club/Academia)
</td>
<td>
Medio
</td>
<td>
Valor real pero no crítico para validar el ciclo básico; dificultad media
</td>
</tr>
<tr>
<td>
12
</td>
<td>
Verificación de club actual/historial vía COMET
</td>
<td>
Medio (bloqueado)
</td>
<td>
Alto valor de confianza del dato, pero bloqueado por acceso externo (sección 35); depende de gestión institucional
</td>
</tr>
<tr>
<td>
13
</td>
<td>
Búsqueda de staff/profesional (Club→Entrenador/Fisio/Prep. físico)
</td>
<td>
Alto
</td>
<td>
Corrección: el actor ya no está diferido a Fase 2 (Etapa 15 corregida); pasa a prioridad Alta, junto a los demás casos de valor incremental sobre el núcleo crítico
</td>
</tr>
<tr>
<td>
14
</td>
<td>
Scouting activo (Scout—Jugador)
</td>
<td>
Alto
</td>
<td>
Corrección: el actor Scout ya no está diferido a Fase 2 (Etapa 15 corregida); sigue dependiendo de volumen de jugadores ya en la plataforma, por lo que se activa después del núcleo crítico, pero dentro del MVP
</td>
</tr>
<tr>
<td>
15
</td>
<td>
Búsqueda de oportunidad laboral (profesionales)
</td>
<td>
Alto
</td>
<td>
Corrección: mismo motivo que el ítem 13; el actor ya no está diferido a Fase 2
</td>
</tr>
<tr>
<td>
16
</td>
<td>
Recuperación / servicio complementario (Jugador—Fisio/Prep. físico)
</td>
<td>
Alto
</td>
<td>
Corrección: depende de que los profesionales ya estén incorporados a la plataforma, lo cual ahora ocurre desde el MVP (Etapa 15 corregida)
</td>
</tr>
<tr>
<td>
17
</td>
<td>
Multi-filial completa en interfaz (Club—Filial)
</td>
<td>
Futuro
</td>
<td>
Dato ya modelado (Etapa 10-11) pero interfaz diferida según Etapa 15
</td>
</tr>
<tr>
<td>
18
</td>
<td>
Reportes / analytics avanzados
</td>
<td>
Futuro
</td>
<td>
No hay aún usuarios/datos reales suficientes para analizar (depende de Etapa 21-22)
</td>
</tr>
</table>

<callout icon="📊" color="purple_bg">
Resumen (corregido): 7 elementos Críticos (= alcance exacto del MVP de la Etapa 15), 7 Altos (primeras mejoras dentro del mismo MVP, incluyendo los 4 casos de Scout/profesionales tras la corrección de alcance de actores), 2 Medios (uno de ellos bloqueado por acceso externo), 2 Futuros (multi-filial en interfaz y reportes/analytics avanzados). Ya no hay elementos "Futuro" ligados a actores diferidos, porque ningún actor documentado queda fuera del MVP.
</callout>

## Arquitectura Maestra de Agentes (Etapa 17 — completa)

<callout icon="✅" color="green_bg">
Cierre de Etapa 17. Matriz cruzada de los agentes de <b>ejecución en tiempo real de la plataforma</b> (distintos de los agentes de negocio/growth de la sección 19, que operan la construcción y crecimiento del proyecto, no el producto). Formaliza como agentes las 4 capas de Geo (sección 16) más los agentes de Perfil, Contexto, Verificación de Datos, Permisos y Priorización ya descritos de forma implícita en la Arquitectura Conceptual (Etapa 14) y los Flujos (Etapa 13), sin inventar responsabilidades nuevas.
</callout>

```txt
Perfil → Contexto → Agente 1 (Privacidad) → Agente 2 (Descubrimiento) → Agente 3 (Fricción Espacial)
→ Agente 4 (Geo-Matching) → Agente de Verificación de Datos → Agente de Permisos → Agente de Priorización → Acción
```

<table>
<tr>
<td>
Agente
</td>
<td>
Rol
</td>
<td>
Entrada
</td>
<td>
Contexto/Datos que usa
</td>
<td>
Instrucción Core
</td>
<td>
Freno
</td>
<td>
Salida / Entregable
</td>
<td>
Siguiente agente
</td>
<td>
Verificación
</td>
</tr>
<tr>
<td>
Agente de Perfil (Onboarding)
</td>
<td>
Validar y estructurar el perfil creado por el actor
</td>
<td>
Datos ingresados por el usuario/tutor
</td>
<td>
Matriz de Datos (Etapa 10), Permisos (Etapa 12)
</td>
<td>
Verificar atributos obligatorios completos según tipo de actor
</td>
<td>
No crear perfil de menor sin consentimiento parental explícito
</td>
<td>
Perfil validado y estructurado
</td>
<td>
Agente de Contexto
</td>
<td>
Auditor QA (freno "no inventar datos")
</td>
</tr>
<tr>
<td>
Agente de Contexto
</td>
<td>
Construir el contexto operativo del actor
</td>
<td>
Perfil validado
</td>
<td>
Matriz de Contexto (Etapa 4), Relaciones (Etapa 11)
</td>
<td>
Determinar situación típica, atributos y condiciones relevantes
</td>
<td>
No inferir necesidades no declaradas por el usuario
</td>
<td>
Contexto operativo estructurado
</td>
<td>
Agente 1 (Privacidad de Contexto)
</td>
<td>
Consistencia con la Matriz de Contexto
</td>
</tr>
<tr>
<td>
Agente 1 — Privacidad de Contexto
</td>
<td>
Traducir el área geográfica de forma segura
</td>
<td>
Ubicación + Perfil
</td>
<td>
Reglas de ubicación de Permisos (Etapa 12)
</td>
<td>
Ofuscar coordenadas cuando el actor es menor de edad
</td>
<td>
Ofuscar coordenadas de menores de edad
</td>
<td>
Contexto Geo Seguro
</td>
<td>
Agente 2 (Descubrimiento)
</td>
<td>
Ninguna coordenada exacta de menor sale de este agente
</td>
</tr>
<tr>
<td>
Agente 2 — Descubrimiento
</td>
<td>
Localizar entidades relevantes
</td>
<td>
Contexto Geo Seguro + Necesidad
</td>
<td>
Matriz de Necesidades (Etapa 6), entidades Club/Academia/Tryout/Oportunidad (Etapa 10)
</td>
<td>
Buscar entidades relevantes por zona/categoría
</td>
<td>
Consultar caché interno antes de llamar APIs externas
</td>
<td>
Entidades Georreferenciadas Limpias
</td>
<td>
Agente 3 (Fricción Espacial)
</td>
<td>
Sin duplicados; datos institucionales actualizados
</td>
</tr>
<tr>
<td>
Agente 3 — Fricción Espacial
</td>
<td>
Calcular costo real de desplazamiento
</td>
<td>
Entidades + Contexto
</td>
<td>
Ubicación de ambas partes
</td>
<td>
Calcular tiempo, ruta, bloqueos, accesibilidad (no solo distancia)
</td>
<td>
—
</td>
<td>
Entidades Puntuadas + Accesibilidad
</td>
<td>
Agente 4 (Geo-Matching)
</td>
<td>
—
</td>
</tr>
<tr>
<td>
Agente 4 — Geo-Matching
</td>
<td>
Cruzar viabilidad geográfica con compatibilidad deportiva
</td>
<td>
Entidades Puntuadas + Perfil Táctico
</td>
<td>
Matriz de Matching (Etapa 7)
</td>
<td>
Aplicar reglas de compatibilidad del par de actores correspondiente
</td>
<td>
—
</td>
<td>
Recomendaciones justificadas (preliminares)
</td>
<td>
Agente de Verificación de Datos
</td>
<td>
Cumple la regla de compatibilidad de la Matriz de Matching
</td>
</tr>
<tr>
<td>
Agente de Verificación de Datos
</td>
<td>
Etiquetar datos como verificado/declarado según la fuente
</td>
<td>
Recomendaciones preliminares (club actual/historial, certificaciones)
</td>
<td>
Sistema COMET si aplica; backlog de acceso externo (sección 35)
</td>
<td>
Consultar fuente oficial si hay acceso; si no, marcar "declarado"
</td>
<td>
No inventar una verificación si no hay fuente confiable disponible
</td>
<td>
Etiqueta de confianza por dato (verificado/declarado)
</td>
<td>
Agente de Permisos
</td>
<td>
Coincide con el backlog de datos bloqueados (sección 35)
</td>
</tr>
<tr>
<td>
Agente de Permisos
</td>
<td>
Aplicar reglas de visibilidad antes de mostrar resultados
</td>
<td>
Recomendaciones etiquetadas
</td>
<td>
Matriz de Permisos y Visibilidad (Etapa 12)
</td>
<td>
Filtrar según perfil completo/resumen público; ocultar contacto directo
</td>
<td>
No exponer contacto ni ubicación exacta sin autorización/opt-in
</td>
<td>
Recomendaciones filtradas y seguras
</td>
<td>
Agente de Priorización
</td>
<td>
Ningún dato sensible expuesto sin autorización
</td>
</tr>
<tr>
<td>
Agente de Priorización / Recomendación
</td>
<td>
Ordenar resultados finales y generar justificación legible
</td>
<td>
Recomendaciones filtradas y seguras
</td>
<td>
Criterio de "prioridad de resultados" de la Matriz de Matching (Etapa 7)
</td>
<td>
Ordenar por el criterio definido para ese par de matching específico
</td>
<td>
No inventar oportunidades inexistentes
</td>
<td>
Lista final priorizada + justificación
</td>
<td>
Acción del usuario (Etapa 12, "quién puede publicar/contactar")
</td>
<td>
Auditor QA
</td>
</tr>
</table>

<callout icon="💡" color="purple_bg">
Esta matriz no reemplaza a los agentes de negocio de la sección 19 (Analista de Viabilidad, Arquitecto de Ecosistema, Tech Lead, etc.): esos operan sobre <b>el proyecto</b> (cómo se construye y crece la startup); los de esta sección operan <b>dentro del producto</b> en tiempo real, cada vez que un usuario crea un perfil o pide una recomendación.
</callout>

### Agentes adicionales identificados (auditoría de esta sesión — 5 agentes nuevos)

<callout icon="🤖" color="blue_bg">
Analista de Viabilidad + Arquitecto de Ecosistema: al auditar la cadena de 9 agentes contra la columna vertebral (sección 25) y la Arquitectura de Datos (Etapa 18), se detectaron 5 responsabilidades ya implícitas en el diseño pero sin agente/dueño explícito. Decisión del usuario: formalizarlas todas.
</callout>

<table>
<tr>
<td>
Agente
</td>
<td>
Rol
</td>
<td>
Entrada
</td>
<td>
Contexto/Datos que usa
</td>
<td>
Instrucción Core
</td>
<td>
Freno
</td>
<td>
Salida / Entregable
</td>
<td>
Siguiente agente
</td>
<td>
Verificación
</td>
</tr>
<tr>
<td>
Agente de Verificación Institucional (anti-fraude Club/Academia)
</td>
<td>
Confirmar que un Club/Academia que se registra es una institución real, no un perfil fraudulento
</td>
<td>
Datos institucionales declarados al crear la cuenta (Club/Academia)
</td>
<td>
Registros públicos/redes oficiales, COMET si aplica (sección backlog 36)
</td>
<td>
Contrastar existencia real de la institución antes de habilitar publicación de tryouts/oportunidades
</td>
<td>
No habilitar publicación a menores hasta confirmar identidad institucional mínima
</td>
<td>
Etiqueta institucional verificado/declarado
</td>
<td>
Agente de Perfil
</td>
<td>
Auditor QA
</td>
</tr>
<tr>
<td>
Agente de Moderación de Contenido
</td>
<td>
Revisar videos/highlights/fotos antes de publicarse
</td>
<td>
Archivo multimedia subido por el usuario
</td>
<td>
Atributos opcionales de Jugador/Profesional (Etapa 10), reglas de menores (Etapa 12)
</td>
<td>
Detectar contenido inapropiado o que exponga datos sensibles (ej. ubicación exacta visible en video)
</td>
<td>
No publicar contenido de un menor sin el filtro de moderación aprobado
</td>
<td>
Contenido aprobado / rechazado con motivo
</td>
<td>
Agente de Permisos
</td>
<td>
Auditor QA
</td>
</tr>
<tr>
<td>
Agente de Notificaciones / Engagement
</td>
<td>
Avisar proactivamente al usuario de acciones pendientes
</td>
<td>
Match nuevo, tryout por vencer, contacto pendiente de respuesta
</td>
<td>
Match/Recomendación (Etapa 18), Permisos (Etapa 12)
</td>
<td>
Generar el aviso correcto según el evento y el canal preferido del usuario
</td>
<td>
No notificar datos sensibles (ubicación exacta, contacto) fuera de las reglas de Permisos
</td>
<td>
Notificación enviada (push/email)
</td>
<td>
Acción del usuario
</td>
<td>
—
</td>
</tr>
<tr>
<td>
Agente de Compliance de Protección de Menores
</td>
<td>
Auditar de forma unificada que todas las reglas de menores (repartidas hoy en Perfil, Privacidad, Permisos) se cumplan juntas
</td>
<td>
Decisiones de Agente de Perfil, Agente 1 (Privacidad), Agente de Permisos para un caso con menor involucrado
</td>
<td>
Matriz de Permisos (Etapa 12), consentimiento parental
</td>
<td>
Verificar consentimiento parental, ubicación ofuscada y visibilidad restringida antes de cualquier acción externa
</td>
<td>
Bloquear la acción completa si falta cualquiera de las tres garantías de menores
</td>
<td>
Certificado de cumplimiento por caso
</td>
<td>
Auditor QA
</td>
<td>
Auditor QA (freno "no inventar datos" aplicado también aquí: no asumir consentimiento no registrado)
</td>
</tr>
<tr>
<td>
Agente de Seguimiento / Feedback
</td>
<td>
Cerrar el loop entre recomendación y resultado real
</td>
<td>
Match/Recomendación + Contacto (Etapa 18)
</td>
<td>
Historial de Match, resultado declarado por el usuario (ej. ¿se concretó el cambio de club?)
</td>
<td>
Registrar si la recomendación produjo una acción real y su resultado
</td>
<td>
No inferir un resultado que el usuario no confirmó explícitamente
</td>
<td>
Dato de Seguimiento (éxito/fracaso/sin respuesta) para alimentar Etapa 21-22
</td>
<td>
Etapa 21 (Validación) / Etapa 22 (Iteración)
</td>
<td>
Analista de Datos (Fase de Medición, sección 19)
</td>
</tr>
<tr>
<td>
Agente de Soporte y Disputas
</td>
<td>
Mediar y resolver conflictos entre usuarios (ej. club no responde, tryout cancelado sin aviso, desacuerdo sobre un dato)
</td>
<td>
Reporte/queja de un usuario
</td>
<td>
Historial de Match/Contacto (Etapa 18), Matriz de Permisos (Etapa 12), Compliance de Menores si aplica
</td>
<td>
Investigar el caso con ambas partes y proponer una resolución dentro de las reglas ya definidas
</td>
<td>
No exponer a una parte datos de la otra más allá de lo ya autorizado por Permisos
</td>
<td>
Resolución de la disputa + registro del caso
</td>
<td>
Agente de Seguimiento/Feedback
</td>
<td>
Auditor QA
</td>
</tr>
</table>

<callout icon="⚠️" color="orange_bg">
Alcance en el MVP (Etapa 15): de estos 5, <b>Compliance de Menores</b> y <b>Verificación Institucional</b> son críticos desde el lanzamiento (mismo nivel que los permisos de menores, no negociables). <b>Seguimiento/Feedback</b> es necesario para que la Etapa 21-22 tenga datos reales, también desde el MVP aunque en versión simple (registro manual de resultado). <b>Moderación de Contenido</b> y <b>Notificaciones/Engagement</b> pueden lanzar en versión simplificada (revisión manual básica; notificaciones por un solo canal) y madurar en Fase 2.
</callout>

## Arquitectura de Datos (Etapa 18 — completa)

<callout icon="✅" color="green_bg">
Cierre de Etapa 18. Formaliza como modelo de datos (entidades/tablas, relaciones, estados e históricos) todo lo ya definido en las Etapas 10 (Datos), 11 (Relaciones), 12 (Permisos), 6 (Necesidades), 7 (Matching) y el backlog de la sección 35, sin crear entidades nuevas no sustentadas.
</callout>

```txt
Usuario → (Jugador | Niño/Joven − Familia | Club − Filial | Academia | Scout | Profesional)
Club/Academia − Competición − Categoría − Temporada
Jugador − HistorialClub (1:N, obligatorio) − Club − Temporada
Tryout − Postulación − Jugador
Match → Contacto (opt-in) ; Match − VerificaciónDato ; Match − PermisoVisibilidad
```

<table>
<tr>
<td>
Entidad (tabla)
</td>
<td>
Campos clave
</td>
<td>
Relaciones principales
</td>
<td>
Estados / histórico
</td>
<td>
Fundamento
</td>
</tr>
<tr>
<td>
Usuario
</td>
<td>
id, email, tipo\_actor, fecha\_registro
</td>
<td>
1:1 con el perfil específico según tipo\_actor
</td>
<td>
Activo / suspendido
</td>
<td>
Etapa 9 (Actores)
</td>
</tr>
<tr>
<td>
Jugador
</td>
<td>
id, posición, categoría, tiene\_experiencia\_previa (bool, declarado por el usuario); club\_actual\_id (FK) y categoría/competición/temporada solo aplicables si tiene\_experiencia\_previa = true
</td>
<td>
N:1 Club actual (condicional); 1:N HistorialClub (condicional); N:1 Familia (si menor)
</td>
<td>
con experiencia previa / sin experiencia previa (corrección de Etapa 9: ya no se asume club por defecto)
</td>
<td>
Etapa 9-10, corregido tras feedback del usuario
</td>
</tr>
<tr>
<td>
Niño/Joven
</td>
<td>
id, edad, experiencia\_previa
</td>
<td>
N:1 Familia (obligatoria); N:1 Academia de interés
</td>
<td>
Interesado / inscrito
</td>
<td>
Etapa 9-10
</td>
</tr>
<tr>
<td>
Familia
</td>
<td>
id, presupuesto, preferencias
</td>
<td>
1:N Niño/Joven a cargo
</td>
<td>
—
</td>
<td>
Etapa 9-10
</td>
</tr>
<tr>
<td>
Club
</td>
<td>
id, nombre, sede, categorías, temporada\_activa\_id (FK)
</td>
<td>
1:N Filial; 1:N Jugador (plantilla); N:N Competición
</td>
<td>
Activo / inactivo por temporada
</td>
<td>
Etapa 9-11
</td>
</tr>
<tr>
<td>
Filial
</td>
<td>
id, club\_padre\_id (FK), nombre
</td>
<td>
N:1 Club padre; N:1 Competición propia (puede diferir de la del club padre)
</td>
<td>
Activa / disuelta
</td>
<td>
Modelo Filial (sección 9, ejemplo Metropolitanos/MetroAEF)
</td>
</tr>
<tr>
<td>
Academia
</td>
<td>
id, programas, precios, horarios, cupos
</td>
<td>
1:N Niño/Jugador inscrito; N:1 Ubicación
</td>
<td>
Cupos disponibles / llenos
</td>
<td>
Etapa 9-10
</td>
</tr>
<tr>
<td>
Scout
</td>
<td>
id, zona\_cobertura, especialización, club\_id (FK, opcional)
</td>
<td>
N:1 Club (0:1, independiente si nulo)
</td>
<td>
— (Fase 2, fuera del MVP)
</td>
<td>
Etapa 9-11
</td>
</tr>
<tr>
<td>
Profesional (Entrenador / Prep. físico / Fisio / Staff / Asistente / Utillero)
</td>
<td>
id, rol, certificaciones, disponibilidad
</td>
<td>
N:1 Club/Academia (0:1)
</td>
<td>
Disponible / contratado (Fase 2, fuera del MVP)
</td>
<td>
Etapa 9-11
</td>
</tr>
<tr>
<td>
Competición
</td>
<td>
id, nombre, tipo (profesional\_nacional / amateur\_nacional / regional\_asociacion / privada\_academia / colegial), es\_regional\_de (FK a Competición padre, nullable — ej. las ligas de la AFDC son "regional\_asociacion" bajo la asociación Distrito Capital), instancia\_comet (nullable)
</td>
<td>
1:N Categoría; 1:N Temporada; N:N Club/Filial
</td>
<td>
—
</td>
<td>
Sección 10 (regla de competiciones) + COMET; enum "tipo" refinado tras la investigación de esta sesión para no confundir la Tercera División nacional (amateur\_nacional, ej. Liga FUTVE 3/AC3) con la Tercera División propia de la AFDC (regional\_asociacion) ni con ligas privadas tipo Pipo Rossi/LIDES (privada\_academia)
</td>
</tr>
<tr>
<td>
Categoría
</td>
<td>
id, nombre, rango\_edad
</td>
<td>
N:1 Competición
</td>
<td>
—
</td>
<td>
Etapa 10
</td>
</tr>
<tr>
<td>
Temporada
</td>
<td>
id, fecha\_inicio, fecha\_fin, competición\_id (FK)
</td>
<td>
1:N HistorialClub
</td>
<td>
Activa / cerrada
</td>
<td>
Etapa 10
</td>
</tr>
<tr>
<td>
HistorialClub <span color="red">(obligatorio solo si el jugador declaró tener experiencia previa / club, no para todo jugador)</span>
</td>
<td>
id, jugador\_id (FK), club\_id (FK), temporada\_id (FK), fecha\_inicio, fecha\_fin
</td>
<td>
N:1 Jugador; N:1 Club; N:1 Temporada
</td>
<td>
Activo / finalizado
</td>
<td>
Corrección del usuario (sección 9): historial obligatorio, no opcional
</td>
</tr>
<tr>
<td>
Tryout
</td>
<td>
id, club\_id/academia\_id (FK), categoría\_id (FK), fecha, ubicación
</td>
<td>
N:1 Club/Academia; 1:N Postulación
</td>
<td>
Abierto / cerrado
</td>
<td>
Etapa 12 (Matriz de Casos)
</td>
</tr>
<tr>
<td>
Postulación
</td>
<td>
id, jugador\_id (FK), tryout\_id (FK)
</td>
<td>
N:1 Jugador; N:1 Tryout
</td>
<td>
Pendiente / aceptada / rechazada
</td>
<td>
Etapa 12 (Matriz de Casos)
</td>
</tr>
<tr>
<td>
Oportunidad (laboral)
</td>
<td>
id, club\_id/academia\_id (FK), rol\_buscado
</td>
<td>
N:1 Club/Academia; N:1 Profesional (Fase 2)
</td>
<td>
Abierta / cubierta (Fase 2, fuera del MVP)
</td>
<td>
Etapa 12 (Matriz de Casos)
</td>
</tr>
<tr>
<td>
Match / Recomendación
</td>
<td>
id, actor\_origen\_id, actor\_destino\_id, tipo\_match, score, justificación
</td>
<td>
Generado por Agente 4 + Agente de Priorización (Etapa 17)
</td>
<td>
Nueva / vista / contactada / descartada
</td>
<td>
Etapa 14 (Arquitectura conceptual) + Etapa 17 (Agentes)
</td>
</tr>
<tr>
<td>
Contacto (opt-in)
</td>
<td>
id, match\_id (FK), solicitante\_id
</td>
<td>
N:1 Match
</td>
<td>
Solicitado / aceptado / rechazado
</td>
<td>
Etapa 12 (contacto oculto por defecto)
</td>
</tr>
<tr>
<td>
VerificaciónDato
</td>
<td>
id, entidad\_referenciada, campo, fuente (COMET/declarado), fecha
</td>
<td>
Asociada a Jugador.club\_actual, HistorialClub, certificaciones de Profesional
</td>
<td>
Verificado / declarado
</td>
<td>
Sección 35 (backlog COMET) + Agente de Verificación (Etapa 17)
</td>
</tr>
<tr>
<td>
PermisoVisibilidad
</td>
<td>
id, actor\_id (FK), campo, nivel\_visibilidad
</td>
<td>
N:1 Usuario/Actor
</td>
<td>
Público / restringido / oculto
</td>
<td>
Etapa 12 (Matriz de Permisos)
</td>
</tr>
</table>

<callout icon="⚠️" color="orange_bg">
Campos marcados "Fase 2, fuera del MVP" (Scout, Profesional, Oportunidad) se modelan aquí para no romper el esquema después, pero no se activan en la interfaz ni en el matching hasta pasar el MVP (Etapa 15). El campo <code>instancia_comet</code> y la tabla <code>VerificaciónDato</code> dependen del acceso externo pendiente (sección 35): se pueden crear vacíos/nulos desde el MVP.
</callout>

## Arquitectura Técnica (Etapa 19 — completa)

<callout icon="✅" color="green_bg">
Cierre de Etapa 19 a nivel de <b>definición/especificación</b>: mapea cada capa técnica requerida por lo ya construido (Agentes de la Etapa 17, Datos de la Etapa 18, Geo de la sección 16, Permisos de la Etapa 12) contra herramientas candidatas. La conexión real y la implementación del código quedan para la fase de construcción en <b>Antigravity</b> (reglas 42-43), sobre el repositorio <b>github.com/futebolfer/futbol</b>.
</callout>

<table>
<tr>
<td>
Capa
</td>
<td>
Requisito (de qué etapa viene)
</td>
<td>
Candidata técnica
</td>
<td>
Justificación
</td>
<td>
Estado
</td>
</tr>
<tr>
<td>
Frontend
</td>
<td>
Interfaz de la Etapa 20 (onboarding, perfiles, dashboards, búsqueda, mapas)
</td>
<td>
Framework web moderno (a confirmar en Antigravity)
</td>
<td>
Debe soportar formularios de perfil por tipo de actor, mapas interactivos y dashboards diferenciados (sección 4)
</td>
<td>
Pendiente de definir en Antigravity
</td>
</tr>
<tr>
<td>
Backend / Orquestación de agentes
</td>
<td>
Pipeline de 9 agentes encadenados (Etapa 17)
</td>
<td>
Servicio backend que ejecute cada agente como un paso con entrada/salida definida (contrato, sección 18)
</td>
<td>
Cada agente ya tiene rol, entrada, freno y salida exacta; encaja en una orquestación secuencial verificable
</td>
<td>
Pendiente
</td>
</tr>
<tr>
<td>
Base de datos
</td>
<td>
20 entidades/tablas relacionales con estados e histórico (Etapa 18)
</td>
<td>
Base de datos relacional (ej. PostgreSQL vía Supabase, ya listada como candidata original)
</td>
<td>
Las relaciones N:1/N:M, claves foráneas y tablas de estado/histórico (HistorialClub, Postulación) son nativas de un modelo relacional
</td>
<td>
Pendiente
</td>
</tr>
<tr>
<td>
Autenticación
</td>
<td>
Perfiles diferenciados por actor + consentimiento parental (Etapa 12)
</td>
<td>
Auth con roles por tipo de actor y flujo de verificación de tutor para menores
</td>
<td>
Los permisos de la Etapa 12 dependen de saber con certeza qué actor es y si requiere consentimiento parental
</td>
<td>
Pendiente
</td>
</tr>
<tr>
<td>
Geolocalización
</td>
<td>
Agente 1 (Privacidad), Agente 2 (Descubrimiento), Agente 3 (Fricción Espacial) — sección 16
</td>
<td>
Proveedor de mapas/geocoding con cálculo de tiempo de viaje real (no solo distancia)
</td>
<td>
La sección 17 exige tiempo + transporte + ruta + horario, no solo coordenadas
</td>
<td>
Pendiente
</td>
</tr>
<tr>
<td>
Integraciones externas (APIs)
</td>
<td>
Verificación vía COMET (bloqueada, sección 35)
</td>
<td>
Conector API bajo estándar FIFA Connect, gestionado vía MCP cuando exista acceso otorgado por la FVF/asociación regional
</td>
<td>
Ya investigado en la sección "Fuentes de datos externas — Sistema COMET"
</td>
<td>
Bloqueado por acceso institucional (no técnico)
</td>
</tr>
<tr>
<td>
Repositorio / control de versiones
</td>
<td>
Regla fijada 42-43
</td>
<td>
github.com/futebolfer/futbol
</td>
<td>
Ya decidido por el usuario como fuente única de verdad del código
</td>
<td>
Definido; conexión formal de lectura/escritura pendiente en Antigravity
</td>
</tr>
<tr>
<td>
Almacenamiento de archivos
</td>
<td>
Atributos opcionales: videos/highlights, fotos (Etapas 10 y 15)
</td>
<td>
Almacenamiento de objetos (ej. Supabase Storage)
</td>
<td>
Son atributos opcionales, fuera del alcance crítico del MVP, pero deben tener dónde vivir cuando se activen
</td>
<td>
Pendiente, no crítico para el MVP
</td>
</tr>
<tr>
<td>
Seguridad
</td>
<td>
Matriz de Permisos (Etapa 12) + frenos de agentes (sección 23)
</td>
<td>
Cifrado de ubicación exacta de menores + control de acceso a nivel de fila (row-level security)
</td>
<td>
Los frenos "no exponer coordenadas de menores" y "no exponer contacto sin opt-in" deben aplicarse también a nivel de base de datos, no solo del agente
</td>
<td>
Pendiente
</td>
</tr>
<tr>
<td>
Logs / auditoría
</td>
<td>
Trazabilidad y auditabilidad (regla 37)
</td>
<td>
Registro de cada decisión del Agente de Verificación de Datos y del Agente de Permisos (Etapa 17)
</td>
<td>
Permite auditar después por qué se mostró u ocultó una recomendación específica
</td>
<td>
Pendiente
</td>
</tr>
<tr>
<td>
Analytics
</td>
<td>
Validación con casos reales (Etapa 21)
</td>
<td>
Registro básico de eventos (perfil creado, match mostrado, contacto solicitado) desde el MVP
</td>
<td>
Sin esto no se puede validar si el sistema "entendió el contexto, detectó necesidad, hizo matching" (checklist de la Etapa 21); los dashboards avanzados quedan en "Futuro" (Etapa 16, ítem 18)
</td>
<td>
Mínimo viable requerido desde el MVP
</td>
</tr>
</table>

<callout icon="💡" color="purple_bg">
Esta tabla es una especificación de requisitos por capa, no una decisión de stack cerrada: la selección final de herramientas (framework de frontend, proveedor de mapas, etc.) se confirma al conectar Antigravity con el repositorio, aplicando siempre la regla maestra de la sección 32 ("no construir porque podemos, construir porque resuelve una necesidad").
</callout>

## Fuentes de datos externas — Sistema COMET (insumo para Etapa 10 / 18-19)

<callout icon="🔎" color="blue_bg">
Investigación puntual: ¿existe una fuente oficial para verificar qué jugadores están inscritos en la nómina de un club a nivel federativo? Sí: el sistema COMET, con hallazgos confirmados específicamente para Venezuela.
</callout>

<table>
<tr>
<td>
Hallazgo
</td>
<td>
Detalle
</td>
</tr>
<tr>
<td>
Qué es COMET
</td>
<td>
Competition Management Expert System, de Analyticom: sistema de gestión de fútbol usado por federaciones y ligas en los 6 continentes (clubes, jugadores, inscripciones, traspasos, contratos, árbitros, competiciones)
</td>
</tr>
<tr>
<td>
Confirmado en Venezuela — nivel federativo
</td>
<td>
La Federación Venezolana de Fútbol (FVF) exige a los clubes usar COMET para cargar la documentación de inscripción de jugadores; confirmado para la Liga FUTVE Junior (32 clubes, +4.400 atletas 2004-2010)
</td>
</tr>
<tr>
<td>
Confirmado en Venezuela — nivel regional
</td>
<td>
Asociaciones afiliadas corren su propia instancia de COMET: Asociación de Fútbol del Distrito Capital y ASOFMIRANDA (Miranda)
</td>
</tr>
<tr>
<td>
No confirmado
</td>
<td>
Sin evidencia de que Canguro, Diamante, Pipo, LIDES o Colegial usen COMET; son ligas/torneos de carácter privado/de academias, probablemente con inscripción interna propia y sin fuente unificada
</td>
</tr>
<tr>
<td>
Acceso técnico
</td>
<td>
COMET expone una REST API bajo el estándar FIFA Connect (competition, matches, match players, etc.), pero no es pública: cada federación/asociación otorga su propia API key. Se requeriría gestión formal con la FVF o la asociación regional para integrarla
</td>
</tr>
</table>

<callout icon="💡" color="purple_bg">
Implicación para el modelo: para competiciones oficiales afiliadas a la FVF, COMET es la fuente de verdad candidata para verificar "club actual" e "historial de clubes" del Jugador (Etapa 10). Para ligas privadas/academias, esa verificación seguirá dependiendo de dato declarado por el usuario/club, sin contraste automatizado. Pendiente de decisión de producto: si se solicita acceso API a la FVF en la fase de Arquitectura Técnica (Etapa 19), o si se mantiene como dato no verificado en el MVP.
</callout>

#

10. Competiciones del fútbol venezolano — regla para Claude Code

<callout icon="⚠️" color="orange_bg">
<b>La investigación deportiva debe ser exhaustiva y detallada.</b> No limitarse a Asofútbol, Canguro, Diamante, Pipo. También investigar divisiones, categorías, ediciones, temporadas, LIDES, Colegial, y cualquier otra competición/estructura relevante. Esta instrucción debe repetirse en cada código de trabajo entregado a Claude Code relacionado con datos deportivos.
</callout>

```txt
NO SUPONER → INVESTIGAR → CONTRASTAR → ESTRUCTURAR → UTILIZAR
```

<callout icon="🔎" color="blue_bg">
Actualización de investigación (esta sesión): se amplía el mapeo de competiciones venezolanas más allá de Asofútbol/Canguro/Diamante/Pipo/LIDES/Colegial, cubriendo también fútbol femenino, futsal, y la estructura regional oficial de la FVF. Se marca cada hallazgo como confirmado (con fuente) o pendiente de contraste, sin inventar datos.
</callout>

<table>
<tr>
<td>
Categoría
</td>
<td>
Competición / estructura
</td>
<td>
Estado
</td>
</tr>
<tr>
<td>
Masculino profesional (FVF)
</td>
<td>
Liga FUTVE (1ª división), Liga FUTVE 2 (2ª división), Torneo de Reservas de Venezuela
</td>
<td>
Confirmado — organizadas por la FVF / Liga de Fútbol Profesional de Venezuela
</td>
</tr>
<tr>
<td>
Tercera División de Venezuela («sLiga FUTVE 3») — nacional, por FVF
</td>
<td>
Existe como categoría/torneo real (fundada 2007, \~41 clubes históricamente, organizados por estado; temporada 2024/2025 con clubes activos como Academia Emeritense, Agua Dulce FC, Arroceros de Calabozo, etc., según Wikipedia/national-football-teams.com), con Torneo Apertura y Clausura, buscando ascenso a la Segunda División; fue declarada categoría <b>amateur</b> en la temporada 2009/2010; en julio 2021 la <b>Asociación de Clubes de Tercera División de Venezuela (AC3)</b> anunció que cambiaría su nombre a <b>Liga FUTVE 3</b>, manteniendo un formato igual al de las ligas que integran Liga FUTVE
</td>
<td>
Duda del usuario confirmada como parcialmente válida y matizada esta sesión: «Liga FUTVE 3» no es solo un nombre coloquial, es el nombre oficial adoptado por AC3 en 2021 con formato igual a Liga FUTVE, pero la categoría sigue siendo amateur desde 2009/2010 (no profesional como 1ª/2ª); es una competición <b>nacional por FVF</b>, distinta de la «Tercera División» propia de la AFDC (ver fila de ligas privadas), que es solo una categoría mayor local del Distrito Capital y no forma parte de este sistema nacional
</td>
</tr>
<tr>
<td>
Copas nacionales
</td>
<td>
Copa Venezuela (clubes de 1ª y 2ª división), Supercopa de Venezuela
</td>
<td>
Confirmado
</td>
</tr>
<tr>
<td>
Femenino
</td>
<td>
Primera División Femenina de Venezuela (antes Liga Nacional de Fútbol Femenino, divisiones Superior/Promocional), Copa Venezuela Femenina (clubes de 15 estados)
</td>
<td>
Confirmado — organizadas por la FVF vía Comisión de Fútbol Femenino
</td>
</tr>
<tr>
<td>
Futsal / Fútbol Sala
</td>
<td>
Liga FUTVE Futsal 1 (máxima categoría, dependiente de la FVF), Liga Premier Futsal de Venezuela, FUNLINAFUTSAL (Liga Nacional Comunitaria de Futsal Menor), AMF Venezuela (fútbol de salón, rama distinta del futsal FIFA)
</td>
<td>
Confirmado como estructuras existentes; jerarquía/afiliación exacta entre ellas pendiente de contraste adicional
</td>
</tr>
<tr>
<td>
Estructura regional oficial
</td>
<td>
24 asociaciones estadales afiliadas a la FVF (una por estado), cada una organiza competiciones locales/de base propias
</td>
<td>
Confirmado — dato oficial de la FVF; el listado de las 24 asociaciones una por una queda pendiente de recopilar
</td>
</tr>
<tr>
<td>
Ligas/torneos privados o de academias
</td>
<td>
Asociación de Fútbol del Distrito Capital (AFDC/Asofútbol Distrito Capital) — según su propia página «Nosotros» organiza actualmente: Liga Canguro Diamante, Liga Raudix Platino, Liga Distrital Titanio, Liga Distrital Azabache, Liga Distrital Futsal, Torneo Sub-20, <b>Primera Distrital</b> y Liga Canguro Esmeralda; categorías mayores adicionales documentadas en prensa: Sub-20, Sub-23, Primera Distrital y una <b>Tercera División propia de AFDC</b> (distinta de la Tercera División de Venezuela/FVF); 102 clubes, 429 equipos, \~7.900 jugadores de 6 a 20 años; afiliada a la FVF y al IND; Liga Pipo Rossi; LIDES (Liga Deportiva Estudiantil de Venezuela); Liga Colegial de Fútbol de Venezuela
</td>
<td>
Corregido esta sesión (petición del usuario): la AFDC no es solo «Canguro/Diamante» ni se limita a categorías infantiles — tiene varias ligas nombradas por sponsor (que cambian de nombre por temporada/torneo) y llega hasta categorías mayores (Sub-20, Sub-23, Primera Distrital); nombres como Distrital Gema/Cuarzo, Diablitos Platino, Redvital Titanio vistos en sesiones previas son variantes de patrocinio de estas mismas ligas, no ligas adicionales distintas; ediciones exactas de cada torneo siguen pendientes de investigación exhaustiva (regla de la sección 10)
</td>
</tr>
<tr>
<td>
Fútbol universitario
</td>
<td>
No se confirmó una liga universitaria de fútbol nacional propia en Venezuela (a diferencia de Uruguay/Colombia, donde sí existen); lo más cercano son canteras/clubes formativos como Universitarios F.C. (Mérida), que no es una liga universitaria sino un club de formación
</td>
<td>
No confirmado — no se documenta como competición para evitar inventar una estructura que no existe
</td>
</tr>
</table>

<callout icon="🔎" color="blue_bg">
Las 24 asociaciones estadales, contrastado esta sesión: confirmado que la FVF está integrada por <b>24 asociaciones estadales</b> (una por cada estado de Venezuela, incluyendo Distrito Capital/AFDC), cada una encargada de organizar el fútbol en su territorio (ligas menores, categorías base, torneos regionales). Dato histórico relevante: la gestión actual de la FVF pasó de solo <b>12 asociaciones activas/reconocidas</b> al inicio de su período a integrar formalmente las <b>24</b> mediante la iniciativa «24 Asociaciones, 24 Canchas» (infraestructura) y un proceso de estandarización de estatutos. En noviembre 2025 se celebraron elecciones de Consejos Directivos 2026-2030 en 22 de las 24 asociaciones (faltando completar 2 al momento de esa nota), lo que confirma que son entidades <b>activas y con autoridades propias</b>, no solo nominales. Cada asociación estadal es análoga en rol a la AFDC (Distrito Capital) que ya se documentó en detalle: organiza sus propias ligas de base/aficionadas, y sus estatutos se están alineando con los de la FVF nacional.
</callout>

<callout icon="🔎" color="blue_bg">
LIDES y Liga César Del Vecchio (Distrito Capital), contrastado esta sesión: <b>LIDES</b> (Liga Deportiva Estudiantil de Venezuela), fundada en 1986, organiza el <b>Torneo Luis Alfredo Mendoza («Mendocita»)</b> y una categoría «Segunda Categoría» con grupos A/B. La <b>Liga César Del Vecchio</b> fue fundada en <b>1968</b> —es decir, ya existía antes y en paralelo a LIDES, «a la sombra» de esta por ser la de más tradición en su momento, según su propio presidente; <b>no</b> se confirma la hipótesis previa de que fue creada por clubes que migraron de LIDES en 1998-99 (dato anterior sin fuente directa, se retira). Lo que sí está confirmado: en la temporada 2003-2004 creó una <b>Serie B</b> para dar espacio a clubes nuevos y a los segundos equipos de clubes ya consolidados; llegó a tener 16 clubes en 1997-98 y 11 clubes en 2019; está afiliada a la AFDC (Asociación de Fútbol del Distrito Capital), y mantiene categorías hasta Sub-21 (A y B).
</callout>

<callout icon="📌">
Decisión aplicada: se documentan solo los hallazgos con fuente verificable; el fútbol universitario venezolano NO se añade como competición porque no se encontró evidencia de que exista como liga federada. El backlog de la sección 35 se mantiene vigente para todo lo que siga pendiente de contraste institucional (COMET, estructura completa de ligas privadas, etc.).
</callout>

# 11-14. Matrices construidas

<callout icon="✅" color="green_bg">
Reconstruidas en esta sesión a partir de la Matriz de Actores (Etapa 9) y la Matriz de Datos (Etapa 10), sin inventar actores ni atributos nuevos. Resuelve el hallazgo crítico de la auditoría transversal (ver sección de Auditoría, más abajo).
</callout>

##

11. Matriz de Contexto

Determina qué información contextual necesita el sistema para entender a cada actor:

```txt
ACTOR + ATRIBUTOS + RELACIONES + SITUACIÓN + NECESIDAD + UBICACIÓN + CONDICIONES = CONTEXTO
```

<table>
<tr>
<td>
Actor
</td>
<td>
Situación / estado típico
</td>
<td>
Atributos que aportan contexto
</td>
<td>
Relaciones activas
</td>
<td>
Ubicación / condiciones
</td>
<td>
Contexto resultante
</td>
</tr>
<tr>
<td>
Jugador (con club)
</td>
<td>
Activo en un club, en una temporada/competición dada
</td>
<td>
Club actual, categoría, competición, edad, posición, historial de clubes
</td>
<td>
Club, Entrenador, Preparador físico, Fisioterapeuta, Familia (si menor), Scouts que lo siguen
</td>
<td>
Ubicación protegida; puede estar evaluando cambio de club
</td>
<td>
Jugador activo evaluando continuidad o cambio dentro de su nivel competitivo actual
</td>
</tr>
<tr>
<td>
Niño / joven (sin club)
</td>
<td>
Nunca ha jugado o busca iniciarse
</td>
<td>
Edad, ubicación, tutor/familia, experiencia previa (ninguna/informal)
</td>
<td>
Familia (obligatoria), Academia/Club de interés
</td>
<td>
Ubicación siempre ofuscada (menor)
</td>
<td>
Interesado en iniciación, sin trayectoria formal aún
</td>
</tr>
<tr>
<td>
Familia / Representante
</td>
<td>
Gestionando la carrera deportiva de uno o más menores
</td>
<td>
Presupuesto, preferencias de horario/distancia, cantidad de menores a cargo
</td>
<td>
Niño/Jugador(es), Club, Academia
</td>
<td>
Ubicación de residencia, restricciones de traslado
</td>
<td>
Decisor y filtro de seguridad para el menor
</td>
</tr>
<tr>
<td>
Club
</td>
<td>
Necesita cubrir plantilla o staff, o dar visibilidad institucional
</td>
<td>
Competición(es)/filiales, categorías, temporada activa, vacantes abiertas
</td>
<td>
Jugadores, Equipos, Filiales, Staff, Academia (si aplica), Competición
</td>
<td>
Ubicación fija (sede), zona de influencia
</td>
<td>
Institución con necesidades puntuales por categoría/temporada/filial
</td>
</tr>
<tr>
<td>
Academia
</td>
<td>
Formando jugadores jóvenes, gestionando inscripciones
</td>
<td>
Programas por edad, precios, horarios, cupos
</td>
<td>
Niño/joven, Familia, Jugador, Entrenador
</td>
<td>
Ubicación fija, zona de cobertura
</td>
<td>
Oferta formativa activa buscando demanda por zona/edad
</td>
</tr>
<tr>
<td>
Scout
</td>
<td>
Buscando activamente perfiles para un club o de forma independiente
</td>
<td>
Zona de cobertura, especialización (posición/categoría)
</td>
<td>
Jugador, Club (0:1)
</td>
<td>
Puede operar en múltiples ubicaciones/zonas
</td>
<td>
En modo de búsqueda/filtrado continuo, no de publicación
</td>
</tr>
<tr>
<td>
Entrenador / Preparador físico / Fisioterapeuta
</td>
<td>
Ofreciendo servicios profesionales, buscando vacante o cliente
</td>
<td>
Certificación, especialidad, disponibilidad horaria
</td>
<td>
Club, Academia, Equipo, Jugador
</td>
<td>
Ubicación y radio de desplazamiento aceptable
</td>
<td>
Profesional en búsqueda activa o pasiva de oportunidades
</td>
</tr>
<tr>
<td>
Staff / Asistente / Utillero / Otros profesionales de apoyo
</td>
<td>
Apoyando la operación de un club/equipo
</td>
<td>
Rol/función, experiencia
</td>
<td>
Club, Equipo
</td>
<td>
Ubicación fija (sede del club)
</td>
<td>
Rol operativo de soporte, generalmente vinculado a un club específico
</td>
</tr>
</table>

##

12. Matriz de Casos

Representa situaciones reales que la plataforma debe resolver (ej. "niño quiere empezar → encontrar opciones de entrenamiento", "club necesita jugador → buscar perfiles", etc.). Evita diseñar funcionalidades abstractas sin casos reales que las justifiquen.

<table>
<tr>
<td>
Caso
</td>
<td>
Actor(es) principal(es)
</td>
<td>
Disparador
</td>
<td>
Qué debe resolver el sistema
</td>
<td>
Resultado esperado
</td>
</tr>
<tr>
<td>
Iniciación deportiva
</td>
<td>
Niño/joven, Familia
</td>
<td>
El menor quiere empezar a jugar fútbol
</td>
<td>
Encontrar academias/clubes de iniciación cercanos, filtrando por edad, precio, horario
</td>
<td>
Lista priorizada de opciones de iniciación con toda la info institucional necesaria
</td>
</tr>
<tr>
<td>
Cambio de club
</td>
<td>
Jugador con club
</td>
<td>
El jugador busca continuar su carrera en otro club
</td>
<td>
Detectar clubes/filiales/categorías/competiciones compatibles con su perfil y ubicación
</td>
<td>
Recomendaciones de clubes con justificación (nivel, distancia, categoría)
</td>
</tr>
<tr>
<td>
Postulación a tryout
</td>
<td>
Jugador / Niño
</td>
<td>
El jugador quiere probar suerte en un club/academia específico
</td>
<td>
Mostrar tryouts abiertos compatibles con edad/categoría/ubicación
</td>
<td>
Lista de tryouts + postulación registrada
</td>
</tr>
<tr>
<td>
Búsqueda de jugadores por perfil
</td>
<td>
Club
</td>
<td>
El club necesita cubrir una posición/categoría
</td>
<td>
Filtrar jugadores por posición, categoría, competición, ubicación, disponibilidad
</td>
<td>
Lista priorizada de candidatos con contexto (club actual, historial)
</td>
</tr>
<tr>
<td>
Publicación de tryout
</td>
<td>
Club / Academia
</td>
<td>
El club/academia abre un proceso de captación
</td>
<td>
Crear y difundir el tryout a los jugadores/niños relevantes por zona/categoría
</td>
<td>
Tryout visible para el público objetivo correcto
</td>
</tr>
<tr>
<td>
Búsqueda de staff/profesional
</td>
<td>
Club / Academia
</td>
<td>
El club necesita entrenador, fisio, preparador físico o asistente
</td>
<td>
Filtrar profesionales por especialidad, certificación, ubicación, disponibilidad
</td>
<td>
Lista priorizada de profesionales compatibles
</td>
</tr>
<tr>
<td>
Scouting activo
</td>
<td>
Scout
</td>
<td>
El scout necesita detectar talento para un club o reporte propio
</td>
<td>
Filtrar jugadores por características, competición, categoría, club, ubicación
</td>
<td>
Watchlist/reporte de jugadores con justificación
</td>
</tr>
<tr>
<td>
Búsqueda de oportunidad laboral
</td>
<td>
Entrenador, Preparador físico, Fisioterapeuta, Asistente
</td>
<td>
El profesional busca trabajo o nuevos clientes
</td>
<td>
Mostrar oportunidades/vacantes compatibles con su perfil y ubicación
</td>
<td>
Lista priorizada de oportunidades
</td>
</tr>
<tr>
<td>
Recuperación / servicio complementario
</td>
<td>
Jugador con club
</td>
<td>
El jugador necesita fisioterapia o preparación física adicional
</td>
<td>
Filtrar profesionales disponibles cercanos con la especialidad requerida
</td>
<td>
Recomendación de profesional + posibilidad de contacto
</td>
</tr>
<tr>
<td>
Verificación de club actual/historial
</td>
<td>
Club, Scout
</td>
<td>
Se necesita confirmar en qué club/filial está inscrito realmente un jugador
</td>
<td>
Consultar fuente verificada (COMET, si aplica) o marcar como "declarado, no verificado"
</td>
<td>
Dato de club actual con nivel de confianza explícito (verificado/declarado)
</td>
</tr>
<tr>
<td>
Selección de academia por familia
</td>
<td>
Familia
</td>
<td>
La familia compara varias academias para su hijo/a
</td>
<td>
Filtrar por ubicación, precio, horario, seguridad, categorías
</td>
<td>
Comparativo priorizado de academias
</td>
</tr>
</table>

##

13. Matriz de Necesidades

```txt
ACTOR → SITUACIÓN → NECESIDAD → INFORMACIÓN NECESARIA → SOLUCIÓN POSIBLE
```

Evita diseñar la plataforma a partir de una lista arbitraria de funcionalidades.

<table>
<tr>
<td>
Actor
</td>
<td>
Situación
</td>
<td>
Necesidad
</td>
<td>
Información necesaria
</td>
<td>
Solución posible
</td>
</tr>
<tr>
<td>
Niño/joven
</td>
<td>
Sin experiencia, quiere iniciarse
</td>
<td>
Encontrar dónde empezar a entrenar
</td>
<td>
Ubicación, edad, precio, horarios, si requiere tryout
</td>
<td>
Recomendación de academias/clubes de iniciación cercanos
</td>
</tr>
<tr>
<td>
Jugador con club
</td>
<td>
Ya juega, busca crecer o cambiar
</td>
<td>
Encontrar otro club, oportunidad, tryout, o servicio profesional
</td>
<td>
Club actual, categoría, competición, historial, ubicación
</td>
<td>
Recomendaciones de clubes/oportunidades/profesionales compatibles
</td>
</tr>
<tr>
<td>
Familia
</td>
<td>
Gestiona la carrera del menor
</td>
<td>
Decidir la mejor opción segura y viable
</td>
<td>
Seguridad, ubicación, precio, categoría, competición, horarios
</td>
<td>
Comparativo de opciones filtradas y priorizadas
</td>
</tr>
<tr>
<td>
Club
</td>
<td>
Necesita cubrir plantilla/staff
</td>
<td>
Encontrar jugadores/profesionales con determinado perfil
</td>
<td>
Perfiles por posición/categoría/ubicación, disponibilidad
</td>
<td>
Lista priorizada de candidatos + herramienta de tryout
</td>
</tr>
<tr>
<td>
Scout
</td>
<td>
Detectar talento
</td>
<td>
Filtrar jugadores por características relevantes
</td>
<td>
Competición, categoría, club, ubicación, contexto
</td>
<td>
Watchlist y reportes de scouting
</td>
</tr>
<tr>
<td>
Fisioterapeuta
</td>
<td>
Ofrece servicios de recuperación
</td>
<td>
Encontrar deportistas/clubes/equipos que lo necesiten
</td>
<td>
Ubicación, especialidad, disponibilidad
</td>
<td>
Lista de oportunidades profesionales compatibles
</td>
</tr>
<tr>
<td>
Preparador físico
</td>
<td>
Ofrece servicios de preparación física
</td>
<td>
Encontrar jugadores/clubes/equipos
</td>
<td>
Ubicación, especialidad, disponibilidad
</td>
<td>
Lista de oportunidades profesionales compatibles
</td>
</tr>
<tr>
<td>
Entrenador
</td>
<td>
Busca trabajo o jugadores/equipos
</td>
<td>
Encontrar vacantes o talento para dirigir
</td>
<td>
Ubicación, certificación, disponibilidad
</td>
<td>
Lista de vacantes/talento compatible
</td>
</tr>
</table>

##

14. Matriz de Matching

```txt
NECESIDAD + PERFIL + CONTEXTO + RESTRICCIONES + DATOS
        ↓
     MATCHING
        ↓
RESULTADOS PRIORIZADOS
```

La plataforma no solo busca; establece compatibilidades y determina qué opción tiene mayor sentido para cada contexto.

<table>
<tr>
<td>
Par de matching
</td>
<td>
Variables de entrada
</td>
<td>
Regla de compatibilidad
</td>
<td>
Prioridad de resultados
</td>
<td>
Freno
</td>
</tr>
<tr>
<td>
Jugador — Club
</td>
<td>
Posición, categoría, competición, ubicación/tiempo de viaje, disponibilidad de vacante
</td>
<td>
El club/filial tiene vacante en la posición/categoría del jugador y la competición es compatible con su nivel actual
</td>
<td>
Menor fricción espacial (Agente 3) + mayor compatibilidad de categoría/competición
</td>
<td>
No recomendar clubes fuera del rango de edad/categoría reglamentario
</td>
</tr>
<tr>
<td>
Jugador — Academia
</td>
<td>
Edad, ubicación, precio, horario, si requiere tryout
</td>
<td>
La academia acepta la edad del niño/joven y su ubicación está dentro de un radio viable
</td>
<td>
Menor tiempo de viaje + mejor ajuste de horario/precio declarado por la familia
</td>
<td>
No mostrar academias sin cupo o fuera de rango de edad
</td>
</tr>
<tr>
<td>
Jugador/Niño — Tryout
</td>
<td>
Categoría, ubicación, fecha, cupo disponible
</td>
<td>
El tryout acepta la categoría/edad del jugador y tiene cupo abierto
</td>
<td>
Proximidad de fecha límite + menor fricción espacial
</td>
<td>
No mostrar tryouts con cupo lleno o fuera de categoría
</td>
</tr>
<tr>
<td>
Club — Profesional (Entrenador/Prep. físico/Fisio/Asistente)
</td>
<td>
Especialidad, certificación, ubicación, disponibilidad, tipo de vacante
</td>
<td>
El profesional tiene la certificación/especialidad requerida y disponibilidad compatible
</td>
<td>
Mejor ajuste de especialidad + menor distancia
</td>
<td>
No recomendar profesionales sin certificación mínima cuando el club la exige
</td>
</tr>
<tr>
<td>
Scout — Jugador
</td>
<td>
Posición, categoría, competición, zona de cobertura del scout
</td>
<td>
El jugador cumple el perfil que el scout está filtrando activamente
</td>
<td>
Relevancia del perfil + actividad reciente del jugador
</td>
<td>
No exponer datos sensibles de menores sin autorización de la familia
</td>
</tr>
<tr>
<td>
Jugador/Profesional — Oportunidad
</td>
<td>
Tipo de oportunidad, requisitos, ubicación, fecha límite
</td>
<td>
El actor cumple los requisitos publicados y está dentro del radio/plazo
</td>
<td>
Proximidad de fecha límite + mejor ajuste de requisitos
</td>
<td>
No inventar oportunidades inexistentes (freno ya definido en sección 23)
</td>
</tr>
</table>

#

15. La columna vertebral conceptual

```txt
ACTORES → PERFILES → CONTEXTO → CASOS → NECESIDADES → DATOS
→ OPORTUNIDADES → MATCHING → RECOMENDACIONES → ACCIÓN → SEGUIMIENTO
```

Y alrededor de todo: <b>Privacidad + Permisos + Geolocalización + Calidad de datos</b>.

#

16. Geolocalización — arquitectura de 4 agentes

No es simplemente "buscar clubes cerca"; incluye cuatro agentes especializados.

<table>
<tr>
<td>
Agente
</td>
<td>
Entrada
</td>
<td>
Función
</td>
<td>
Freno crítico
</td>
<td>
Salida
</td>
</tr>
<tr>
<td>
1. Privacidad de Contexto
</td>
<td>
Ubicación + Perfil
</td>
<td>
Traducir el área geográfica de forma segura
</td>
<td>
Ofuscar coordenadas de menores de edad
</td>
<td>
Contexto Geo Seguro
</td>
</tr>
<tr>
<td>
2. Descubrimiento
</td>
<td>
Contexto Geo + Necesidad
</td>
<td>
Localizar entidades relevantes
</td>
<td>
Consultar caché interno antes de llamar APIs
</td>
<td>
Entidades Georreferenciadas Limpias
</td>
</tr>
<tr>
<td>
3. Fricción Espacial
</td>
<td>
Entidades + Contexto
</td>
<td>
Calcular costo real de desplazamiento (tiempo, ruta, bloqueos, accesibilidad — no solo distancia)
</td>
<td>
—
</td>
<td>
Entidades Puntuadas + Accesibilidad
</td>
</tr>
<tr>
<td>
4. Geo-Matching
</td>
<td>
Entidades + Perfil Táctico
</td>
<td>
Cruzar tiempo de viaje, estructura deportiva real y fecha límite del atleta
</td>
<td>
—
</td>
<td>
Recomendaciones Justificadas
</td>
</tr>
</table>

#

17. Por qué geo es importante

Un club a 5 km no necesariamente es mejor que uno a 12 km. La plataforma considera: <b>Distancia + Tiempo + Transporte + Ruta + Horario + Categoría + Competición + Necesidad + Fecha</b>. Esto convierte el mapa en una herramienta de decisión, no solo visual.

#

18. Arquitectura de agentes — el contrato de trabajo

La arquitectura de agentes no es "Agente → haz algo", sino un contrato:

```txt
AGENTE
├── Rol
├── Entradas
├── Parámetros
├── Instrucción Core
├── Freno
├── Salida Exacta
└── Relación con otros agentes
```

#

19. Agentes existentes por fase

<callout icon="⚠️" color="orange_bg">
Corrección aplicada (auditoría de esta sesión): faltaba por completo la <b>Fase 0 — Auditoría Digital</b>, que sí existe como skill con 4 subagentes propios. Se añade aquí para que las 5 fases de negocio queden completas y trazables una a una con sus skills de origen (Fase 0 a Fase 4).
</callout>

## Fase 0 — Auditoría Digital (IADM)

<table>
<tr>
<td>
Agente
</td>
<td>
Entrada
</td>
<td>
Función
</td>
<td>
Freno
</td>
<td>
Salida
</td>
</tr>
<tr>
<td>
Investigador Digital
</td>
<td>
Empresa, sector, escaneo previo
</td>
<td>
Recopilar la Data Cruda: rendimiento técnico, cumplimiento legal, sentimiento/reputación, ecosistema de canales
</td>
<td>
No puntuar ni recomendar, solo reportar hechos
</td>
<td>
Reporte de Data Cruda por áreas
</td>
</tr>
<tr>
<td>
Evaluador IADM
</td>
<td>
Reporte forense + datos internos del cliente
</td>
<td>
Aplicar el Índice de Arquitectura Digital de Marca (score 1-5 a Presencia, Arquitectura, Experiencia)
</td>
<td>
Si no hay métricas duras, marcar "No evaluable sin acceso a analítica interna"; no inventar números
</td>
<td>
Matriz IADM con columna de Evidencia
</td>
</tr>
<tr>
<td>
Estratega de Brechas
</td>
<td>
Matriz IADM
</td>
<td>
Mapear brechas, priorizar por causa raíz, señalar puntos ciegos
</td>
<td>
Solo el QUÉ hacer, nunca el CÓMO (eso es Fase 1)
</td>
<td>
Bloque de Brechas + Prioridades + Puntos Ciegos
</td>
</tr>
<tr>
<td>
Productor de Diagnóstico
</td>
<td>
Empresa + Matriz IADM + Estrategia
</td>
<td>
Benchmark de competencia y ensamblaje final; conexión obligatoria a Canva
</td>
<td>
—
</td>
<td>
Enlace de Canva del Diagnóstico
</td>
</tr>
</table>

## Fase de Viabilidad / Arquitectura

<table>
<tr>
<td>
Agente
</td>
<td>
Entrada
</td>
<td>
Función
</td>
<td>
Freno
</td>
<td>
Salida
</td>
</tr>
<tr>
<td>
Analista de Viabilidad
</td>
<td>
Diagnóstico Fase 0
</td>
<td>
Mapear brechas a requerimientos; filtrar alcance según presupuesto
</td>
<td>
No diseñar
</td>
<td>
Requerimientos Base + Matriz de Viabilidad
</td>
</tr>
<tr>
<td>
Arquitecto de Ecosistema
</td>
<td>
Requerimientos del Agente 1
</td>
<td>
Diseñar embudos, sitemap, stack técnico/legal
</td>
<td>
No programar
</td>
<td>
Blueprint UX + Funnels + Tech Stack
</td>
</tr>
<tr>
<td>
Arquitecto de Mensaje
</td>
<td>
Requerimientos + Blueprint
</td>
<td>
Definir voz, pilares, ganchos de conversión
</td>
<td>
No redactar copy final
</td>
<td>
Identidad Verbal + Guía de Mensaje
</td>
</tr>
<tr>
<td>
Criterios de Aceptación
</td>
<td>
Blueprint + Identidad
</td>
<td>
Fijar métricas de éxito, entregables, criterios de siguiente fase
</td>
<td>
—
</td>
<td>
Protocolo "Gate to Phase 2"
</td>
</tr>
<tr>
<td>
Productor de Plano
</td>
<td>
Todo lo anterior
</td>
<td>
Ensamblar en Markdown; enviar a Canva vía MCP cuando corresponda
</td>
<td>
—
</td>
<td>
Plano Maestro
</td>
</tr>
</table>

## Fase de Implementación

<table>
<tr>
<td>
Agente
</td>
<td>
Entrada
</td>
<td>
Función
</td>
<td>
Freno
</td>
<td>
Salida
</td>
</tr>
<tr>
<td>
Project Manager
</td>
<td>
Plano Maestro
</td>
<td>
Traducir el plano a sprints y tareas
</td>
<td>
No ejecutar código
</td>
<td>
Backlog + Cronograma
</td>
</tr>
<tr>
<td>
Tech Lead
</td>
<td>
Backlog + Plano Técnico
</td>
<td>
Escribir HTML/CSS/JS, guías CRM, DNS, integraciones
</td>
<td>
No desplegar en servidor
</td>
<td>
Código + Guías de Integración
</td>
</tr>
<tr>
<td>
Copywriter
</td>
<td>
Backlog + Identidad
</td>
<td>
Redactar textos web, emails, ads, SEO
</td>
<td>
—
</td>
<td>
Copywriting Final
</td>
</tr>
<tr>
<td>
Auditor QA
</td>
<td>
Código + Copy + Criterios
</td>
<td>
Cruzar entregables con criterios definidos
</td>
<td>
—
</td>
<td>
Certificado QA + Material Depurado
</td>
</tr>
<tr>
<td>
Gestor de Lanzamiento
</td>
<td>
Todo lo anterior aprobado
</td>
<td>
Ensamblar Manual de Implementación; enviar a Canva vía MCP
</td>
<td>
—
</td>
<td>
Manual Lanzamiento
</td>
</tr>
</table>

## Fase de Medición / Optimización

<table>
<tr>
<td>
Agente
</td>
<td>
Entrada
</td>
<td>
Función
</td>
<td>
Freno
</td>
<td>
Salida
</td>
</tr>
<tr>
<td>
Analista de Datos
</td>
<td>
Métricas del mes + KPIs base
</td>
<td>
Detectar victorias y fugas reales
</td>
<td>
No inventar datos faltantes
</td>
<td>
Reporte de Rendimiento + Fugas
</td>
</tr>
<tr>
<td>
Especialista CRO
</td>
<td>
Reporte de Rendimiento
</td>
<td>
Proponer tests A/B para fricciones UX/UI
</td>
<td>
—
</td>
<td>
Matriz de Experimentos
</td>
</tr>
<tr>
<td>
Gestor de Contenido
</td>
<td>
Reporte + Identidad
</td>
<td>
Eliminar contenido inútil, crear parrilla de 4 semanas, redactar base
</td>
<td>
—
</td>
<td>
Calendario Editorial + Copys
</td>
</tr>
<tr>
<td>
Auditor Técnico
</td>
<td>
Alertas CMS + Search Console
</td>
<td>
Detectar errores 404, velocidad, plugins, problemas técnicos
</td>
<td>
—
</td>
<td>
Tickets de Mantenimiento
</td>
</tr>
<tr>
<td>
Client Success
</td>
<td>
Todo lo anterior
</td>
<td>
Redactar resumen de ROI y planes; enviar a Canva vía MCP
</td>
<td>
—
</td>
<td>
Reporte Directivo
</td>
</tr>
</table>

## Fase de Escalamiento / Growth

<table>
<tr>
<td>
Agente
</td>
<td>
Entrada
</td>
<td>
Función
</td>
<td>
Freno
</td>
<td>
Salida
</td>
</tr>
<tr>
<td>
Director Growth
</td>
<td>
Histórico Fase 3 + Techo
</td>
<td>
Decidir vector de escalamiento (vertical/horizontal/producto)
</td>
<td>
—
</td>
<td>
Vector + Mitigación de Riesgos
</td>
</tr>
<tr>
<td>
Analista de Finanzas
</td>
<td>
Vector + Presupuesto
</td>
<td>
Proyectar escalamiento de Ads y tope de CAC
</td>
<td>
ROAS conservador
</td>
<td>
Plan de Paid Media Escalonado
</td>
</tr>
<tr>
<td>
Arquitecto de Automatización
</td>
<td>
Vector de Escalamiento
</td>
<td>
Diseñar flujos (Make, Zapier, HubSpot, otros)
</td>
<td>
—
</td>
<td>
Blueprint RevOps + Data Flow
</td>
</tr>
<tr>
<td>
Expansor de Autoridad
</td>
<td>
Vector de Escalamiento
</td>
<td>
Diseñar alianzas, PR, guiones de cold emailing
</td>
<td>
—
</td>
<td>
Estrategia PR + Plantillas
</td>
</tr>
<tr>
<td>
Gestor Playbook
</td>
<td>
Todo lo anterior
</td>
<td>
Unificar el plan para inversores, junta, dirección
</td>
<td>
—
</td>
<td>
Master Playbook
</td>
</tr>
</table>

#

20. Lo que esto enseñó sobre los agentes

Los agentes cubren un ciclo completo, no solo detección de problemas:

```txt
ANALIZAR → DECIDIR → PLANIFICAR → DISEÑAR → CONSTRUIR → VERIFICAR
→ LANZAR → MEDIR → OPTIMIZAR → ESCALAR
```

<callout icon="💡">
Descripción correcta del sistema: <b>software completo orquestado por agentes especializados</b>. No: "una colección de agentes".
</callout>

#

21. Adaptabilidad

No significa "un agente puede hacer cualquier cosa", sino:

```txt
CAMBIA EL CONTEXTO → CAMBIA LA NECESIDAD → CAMBIAN LOS AGENTES RELEVANTES
→ CAMBIA EL PROCESO → CAMBIA EL RESULTADO
```

## Dos niveles

<b>Nivel 1 — Adaptabilidad del agente:</b> el mismo agente recibe diferentes contextos y produce diferentes resultados.

<b>Nivel 2 — Adaptabilidad del sistema (más importante):</b> el sistema completo selecciona diferentes procesos según actor, necesidad, contexto, datos, relaciones, ubicación y restricciones. Un niño no necesita el mismo flujo que un scout, un club, o un fisioterapeuta.

#

22. Agentes como unidades de producción

Los agentes no solo producen respuestas: producen <b>entregables verificables</b> (Matriz de Viabilidad, Blueprint, Backlog, Código, Certificado QA, Reporte, Matriz de Experimentos, Vector de Escalamiento, Recomendaciones Justificadas, etc.). Cada agente es una unidad especializada dentro de una cadena de producción de software/decisión.

#

23. Los frenos

<table>
<tr>
<td>
Agente
</td>
<td>
Freno
</td>
</tr>
<tr>
<td>
Analista Viabilidad
</td>
<td>
No diseñar
</td>
</tr>
<tr>
<td>
Arquitecto Ecosistema
</td>
<td>
No programar
</td>
</tr>
<tr>
<td>
Project Manager
</td>
<td>
No ejecutar código
</td>
</tr>
<tr>
<td>
Tech Lead
</td>
<td>
No desplegar
</td>
</tr>
<tr>
<td>
Analista Datos
</td>
<td>
No inventar datos
</td>
</tr>
<tr>
<td>
Matching
</td>
<td>
No inventar oportunidades
</td>
</tr>
<tr>
<td>
Geo
</td>
<td>
No exponer coordenadas sensibles
</td>
</tr>
</table>

Buscamos: <b>Control + Trazabilidad + Auditabilidad</b>.

#

24. Modelo conceptual del motor

```txt
                  DATOS
                    │
                    ↓
                 CONTEXTO
                    │
                    ↓
                 NECESIDAD
                    │
                    ↓
              ORQUESTACIÓN
                    │
          ┌─────────┼─────────┐
          ↓         ↓         ↓
       AGENTE    AGENTE     AGENTE
          │         │         │
          └─────────┼─────────┘
                    ↓
                 MATCHING
                    ↓
              PRIORIZACIÓN
                    ↓
             RECOMENDACIÓN
                    ↓
                  ACCIÓN
                    ↓
               SEGUIMIENTO
```

#

25. Columna vertebral actual (estructura completa)

```txt
STARTUP DEPORTIVA
├── 1. Actores
├── 2. Perfiles
├── 3. Relaciones
├── 4. Contexto
├── 5. Casos
├── 6. Necesidades
├── 7. Datos
├── 8. Oportunidades
├── 9. Descubrimiento
├── 10. Filtrado
├── 11. Geo
├── 12. Matching
├── 13. Recomendaciones
├── 14. Acción
├── 15. Seguimiento
├── 16. Privacidad
├── 17. Permisos
├── 18. Arquitectura de agentes
├── 19. Arquitectura de datos
├── 20. Arquitectura técnica
└── 21. Experiencia / interfaz
```

#

26. Roadmap maestro

## Bloque A — Definición del problema

- <s>Etapa 1 — Definir el problema deportivo</s> — ✅ Hecho
- <s>Etapa 2 — Definir la visión de la plataforma</s> — ✅ Hecho
- <s>Etapa 3 — Definir actores y ecosistema</s> — ✅ Hecho

## Bloque B — Modelado del problema

- Etapa 4 — Matriz de Contexto — ✅ Hecha
- Etapa 5 — Matriz de Casos — ✅ Hecha
- Etapa 6 — Matriz de Necesidades — ✅ Hecha
- Etapa 7 — Matriz de Matching — ✅ Hecha
- Etapa 8 — Inteligencia Geográfica (Privacidad de Contexto, Descubrimiento, Fricción Espacial, Geo-Matching) — 🟡 Iniciada / definida

## Bloque C — Modelado del ecosistema

- <s>Etapa 9 — Actores/Roles: quiénes existen, qué puede hacer cada actor, qué información necesita, qué puede publicar/buscar/ofrecer, con quién puede relacionarse</s> — ✅ Hecho (ver matriz completa en sección 5)
- <s>Etapa 10 — Información/Datos: entidades, atributos, datos obligatorios/opcionales, relaciones, fuentes, actualización, calidad</s> — ✅ Hecho (borrador completo; ver matriz en sección 9)
- <s>Etapa 11 — Relaciones: Jugador→Club, Jugador→Competición, Club→Competición, Club→Categoría, Club→Staff, Profesional→Club, Profesional→Jugador, Scout→Jugador, Academia→Jugador, etc.</s> — ✅ Hecho (mapeo con cardinalidad; ver matriz en sección 9)
- <s>Etapa 12 — Permisos/Visibilidad: qué puede ver/editar/publicar cada actor; qué es privado/público/requiere autorización, especialmente para menores, ubicación y datos personales</s> — ✅ Hecho (matriz completa; ver sección 9)

## Bloque D — Experiencia

- <s>Etapa 13 — Flujos/Experiencias: qué ocurre tras crear cada tipo de perfil (ej. Perfil Jugador → Contexto → Recomendaciones; Perfil Club → Necesidades → Buscador/Matching; Perfil Fisio → Servicios → Oportunidades)</s> — ✅ Hecho (4 flujos críticos bocetados; ver sección 9)
- <s>Etapa 14 — Arquitectura Conceptual: Usuarios → Perfiles → Contexto → Datos → Agentes → Matching → Recomendaciones → Acciones</s> — ✅ Hecho (8 capas formalizadas; ver sección 9). <b>Gate to Phase 2 completo.</b>

## Bloque E — Producto

- <s>Etapa 15 — Definición del MVP: qué entra, qué no, qué debe funcionar primero. Evitar "como podemos hacer muchas cosas, hacemos todas"</s> — ✅ Hecho (alcance de actores/capas + orden de construcción definidos; ver sección 9)
- <s>Etapa 16 — Priorización: Crítico / Alto / Medio / Futuro, según valor, dificultad, dependencia, riesgo, frecuencia, impacto</s> — ✅ Hecho (18 elementos priorizados; ver sección 9)

## Bloque F — Arquitectura de agentes

- <s>Etapa 17 — Cruzar todos los agentes existentes con las matrices. La matriz maestra debe tener: Agente, Rol, Entrada, Contexto, Datos, Instrucción, Freno, Procesamiento, Salida, Entregable, Siguiente Agente, Verificación. Aquí se determina qué agentes se necesitan, cuáles son redundantes, cuáles faltan, cuáles combinar, cuáles son deportivos vs. genéricos/reutilizables, y qué agente activa a cuál</s> — ✅ Hecho (15 agentes de producto: 9 originales encadenados + 6 añadidos en auditoría — Verificación Institucional, Moderación de Contenido, Notificaciones/Engagement, Compliance de Menores, Seguimiento/Feedback, Soporte y Disputas; ver sección 9)

## Bloque G — Arquitectura de datos

- <s>Etapa 18 — Arquitectura de datos: entidades, tablas, relaciones, estados, históricos, temporadas, competencias, categorías, ubicaciones, perfiles, necesidades, oportunidades, matches</s> — ✅ Hecho (20 entidades/tablas con relaciones, estados e histórico; ver sección 9)

## Bloque H — Arquitectura técnica

- <s>Etapa 19 — Frontend, backend, base de datos, autenticación, APIs, geolocalización, agentes, MCP, almacenamiento, seguridad, logs, analytics. Herramientas candidatas: Claude Code, GitHub, Supabase, Vercel, MCP — solo según necesidad real</s> — ✅ Hecho (stack candidato definido por capa; ver sección 9; conexión/implementación real pendiente en Antigravity)

## Bloque I — Producto digital

- Etapa 20 — Construcción de interfaz, onboarding, perfiles, dashboards, búsqueda, filtros, recomendaciones, mapas, oportunidades, perfiles de entidades

## Bloque J — Validación

- Etapa 21 — Probar casos reales: niño de 11 años sin experiencia; jugador perteneciente a club;  jugador buscando oportunidad; club buscando jugador; club buscando fisioterapeuta; scout buscando perfiles; deportista buscando preparador físico; familia buscando academia. Verificar: ¿entendió el contexto?, ¿detectó necesidad?, ¿encontró información?, ¿filtró correctamente?, ¿hizo matching?, ¿recomendó?, ¿la recomendación tiene fundamento?

## Bloque K — Iteración

- Etapa 22 — Datos reales → Errores → Análisis → Cambios → Nueva prueba

#

## Diagnóstico de aceleración (aplicando la arquitectura de agentes de Fase de Viabilidad)

<callout icon="🧭" color="blue_bg">
Ejercicio solicitado: usar el propio marco de agentes ya definido (Fase de Viabilidad) para analizar el avance real del proyecto y proponer cómo acelerar el camino al MVP, sin saltarse pasos.
</callout>

### Analista de Viabilidad — diagnóstico de brechas

- Bloques ya sólidos (100% o casi): Problema, Visión, Matriz de Contexto, Matriz de Casos, Matriz de Necesidades, Matriz de Matching, Actores/Roles, y ahora Información/Datos (borrador completo, Etapa 10).
- La brecha real detectada <b>no es falta de información</b>, sino que el roadmap se ha tratado como estrictamente secuencial cuando no lo es: Relaciones (Etapa 11) y Permisos (Etapa 12) dependen únicamente de Actores + Datos, que ya están cerrados.
- Riesgo: seguir avanzando etapa por etapa en fila retrasa innecesariamente la llegada al MVP (Etapa 15).

### Arquitecto de Ecosistema — propuesta de paralelización

<callout icon="⚡" color="green_bg">
Recomendación: dejar de tratar el Bloque C como secuencial. A partir de aquí, correr en paralelo:
</callout>

- <b>Track 1</b> — Etapa 11 (Relaciones) + Etapa 12 (Permisos/Visibilidad): ambas son mapeos derivados de matrices ya cerradas (Actores + Datos), no requieren nueva investigación de fútbol venezolano ni nuevas decisiones de producto.
- <b>Track 2</b> — Adelantar el arranque de la Etapa 13 (Flujos/Experiencias) para los 3-4 casos más críticos de la Matriz de Casos (niño sin experiencia, jugador buscando oportunidad, club buscando jugador, familia buscando academia), usando ya Actores + Necesidades + Matching. No hace falta esperar el cierre 100% de Relaciones/Permisos para bocetar estos flujos.
- Esto comprime el Bloque C + Bloque D de "secuencial puro" a "parcialmente paralelo", acortando el camino real hacia la Etapa 15 (MVP).

### Criterios de Aceptación — Gate to Phase 2 (antes de entrar a MVP)

Checklist antes de abrir formalmente la Etapa 15:

- [x] Actores/Roles (Etapa 9)
- [x] Información/Datos, borrador completo (Etapa 10)
- [x] Relaciones, mapeo formal con cardinalidad (Etapa 11)
- [x] Permisos/Visibilidad, especialmente menores y ubicación (Etapa 12)
- [x] Al menos 3 flujos de experiencia bocetados y validados contra la Matriz de Casos (Etapa 13)
- [x] Arquitectura conceptual esbozada (Etapa 14)

<callout icon="🏁" color="green_bg">
Gate to Phase 2 cumplido en su totalidad. El próximo paso formal del roadmap es abrir la Etapa 15 (Definición del MVP).
</callout>

### Productor de Plano — hoja de ruta acelerada

```txt
AHORA
  ├─ Track 1 (paralelo): Etapa 11 Relaciones + Etapa 12 Permisos
  └─ Track 2 (paralelo, arranca ya): Etapa 13 Flujos (solo casos críticos)
        ↓
   Etapa 14 — Arquitectura conceptual
        ↓
   Etapa 15 — MVP (Gate to Phase 2 cumplido)
```

<callout icon="💡" color="purple_bg">
Conclusión del diagnóstico: el proyecto no está atrasado en contenido — está atrasado en secuenciación. La columna vertebral conceptual ya tiene suficiente base (Actores + Datos + Necesidades + Casos + Matching) para trabajar Relaciones, Permisos y los primeros Flujos en paralelo, en vez de uno por uno.
</callout>

#

27. Reglas y decisiones ya fijadas
28. La plataforma no es únicamente scouting, ni directorio, ni marketplace, ni red social: integra necesidades en un ecosistema contextual
29. El usuario no elige manualmente qué busca al entrar; el sistema infiere desde el perfil y contexto
30. Las capacidades se organizan por grupos contextuales, subordinados al contexto del usuario
31. Los actores varían según el perfil del usuario; no todos tienen los mismos atributos
32. El jugador debe tener registrado su club actual cuando aplique (con categoría, competición, temporada)
33. Se elimina el campo subjetivo "nivel" (principiante/intermedio/competitivo/avanzado); se usa la estructura deportiva real (competición, división, categoría, club, temporada)
34. Cada entidad requiere una representación rica de datos, no una ficha mínima
35. La investigación del fútbol venezolano debe ser exhaustiva, sin limitarse a Asofútbol/Canguro/Diamante/Pipo; incluir también LIDES, Colegial y otras estructuras, y repetirse esta instrucción en cada entrega a Claude Code
36. Los agentes se definen como contratos de trabajo: Rol, Entradas, Parámetros, Instrucción Core, Freno, Salida Exacta, Relación con otros agentes
37. Los agentes tienen frenos explícitos para garantizar control, trazabilidad y auditabilidad
38. La adaptabilidad opera en dos niveles: del agente (mismo agente, distinto contexto) y del sistema (distinto proceso completo según actor/necesidad/contexto)
39. No se debe mostrar toda la complejidad del sistema al usuario; la complejidad se usa para entregar una experiencia simple
40. No se añaden agentes porque "suenan interesantes"; se añaden cuando una parte del proceso requiere responsabilidad específica, contexto, reglas, frenos y un entregable
41. Claude Code entra después de tener la definición, matrices, arquitectura y especificación — no antes; no debe inventar la arquitectura del producto
42. La plataforma <b>no será de pago</b> para los actores documentados (jugadores, niños/jóvenes, familias, clubes, academias, profesionales, scouts, etc.); esta decisión queda fijada desde ahora. El modelo de monetización (si existe) se diseñará más adelante, pero parte de la restricción de no cobrar acceso a la plataforma ni a sus funciones core a ninguno de estos actores
43. Se agrega el Agente de Soporte y Disputas a la arquitectura de agentes de producto (Etapa 17), para mediar conflictos entre usuarios sin exponer datos más allá de lo ya autorizado por Permisos
44. Todo el trabajo del proyecto (documentación, matrices, roadmap y, más adelante, el código) debe quedar redirigido/sincronizado a un repositorio de GitHub como fuente única de verdad, en línea con el flujo NOSOTROS → DEFINICIÓN → MATRICES → ARQUITECTURA → ESPECIFICACIÓN → IMPLEMENTACIÓN (sección 30). El usuario ya cuenta con un repositorio propio para este fin: <b>github.com/futebolfer/futbol</b>. Se conectará formalmente (lectura/escritura de código) cuando el proyecto llegue a la Etapa 19 (Arquitectura técnica) vía Antigravity, ya que este entorno de documentación solo tiene acceso de lectura a GitHub
45. Este entorno (Notion AI / agente de documentación) <b>no puede escribir código, desplegar, ni hacer push a un repositorio</b>: su conector de GitHub es de solo lectura (buscar/leer PRs, issues, commits, archivos). Aquí solo se construyen documentación, matrices, arquitectura y especificación. La implementación real de la plataforma se ejecuta en una herramienta de código dedicada conectada al repositorio de GitHub. Decisión fijada: por ahora no se usa Claude Code; la implementación se migrará a <b>Antigravity</b> (con sus propios agentes y generación de código) cuando el proyecto llegue a la fase de construcción (Etapas 17-20)

#

28. Qué falta para cerrar la columna vertebral

## Ya construido

- Contexto (concepto y matriz)
- Casos (matriz)
- Necesidades (matriz)
- Matching (matriz)
- Geo — arquitectura inicial (4 agentes)
- Actores / Roles (matriz completa)
- Información / Datos (matriz completa — borrador)
- Relaciones (matriz completa con cardinalidad)
- Permisos / Visibilidad (matriz completa)
- Flujos de experiencia (4 casos críticos bocetados)
- Arquitectura conceptual (8 capas formalizadas)
- Definición del MVP (alcance de actores, capas y orden de construcción)
- Priorización (18 elementos clasificados Crítico/Alto/Medio/Futuro)
- Arquitectura maestra de agentes (9 agentes de producto encadenados)
- Arquitectura de datos (20 entidades/tablas con relaciones y estados)
- Arquitectura técnica (stack candidato definido por capa; ver sección 9)
- Concepto de perfiles
- Concepto de relaciones
- Concepto de adaptabilidad
- Arquitectura de agentes (5 fases completas: Fase 0 — Auditoría Digital, Viabilidad/Arquitectura, Implementación, Medición/Optimización, Escalamiento/Growth)

## Falta cerrar rigurosamente

- MVP (definición completa; construcción pendiente — Etapa 20)
- Arquitectura técnica (definición completa; conexión e implementación real pendiente en Antigravity)

#

29. Qué viene después de la columna vertebral

```txt
MVP → AGENTES → DATOS → STACK → IMPLEMENTACIÓN → VALIDACIÓN
```

<callout icon="🚫" color="red_bg">
Error a evitar: IDEA → APP → 100 FUNCIONES → IA
</callout>

<callout icon="✅" color="green_bg">
Camino correcto: PROBLEMA → ACTORES → CONTEXTO → CASOS → NECESIDADES → DATOS → MATCHING → EXPERIENCIA → MVP → AGENTES → ARQUITECTURA → TECNOLOGÍA → IMPLEMENTACIÓN
</callout>

#

30. Cómo se conecta todo con Claude Code

Claude Code entra <b>después</b> de que se sepa qué se está construyendo. No inventa la arquitectura del producto.

```txt
NOSOTROS → DEFINICIÓN → MATRICES → ARQUITECTURA → ESPECIFICACIÓN
→ CLAUDE CODE → IMPLEMENTACIÓN
```

Claude Code puede: analizar repositorio, crear archivos, crear agentes, implementar, probar, corregir, integrar GitHub, Supabase, Vercel, y MCPs.

## Nota sobre la herramienta de implementación

<callout icon="🔄" color="blue_bg">
Decisión actualizada: la implementación de código no se hace en este entorno de documentación (Notion AI), que no puede escribir ni desplegar código. Por ahora tampoco se usará Claude Code. Cuando el proyecto llegue a la fase de construcción (Etapas 17-20), esta especificación completa (matrices, arquitectura, MVP, priorización) se migrará a <b>Antigravity</b>, usando el repositorio de GitHub del usuario como destino del código. Las reglas de investigación exhaustiva de abajo aplican igual, sin importar la herramienta que finalmente ejecute la implementación.
</callout>

## Regla permanente para cada entrega a Claude Code

<callout icon="⚠️" color="orange_bg">
Investigar de forma exhaustiva y detallada la estructura real del fútbol venezolano. No limitarse a las competiciones más conocidas. Investigar competiciones, divisiones, categorías, temporadas, ediciones, clubes y estructuras relevantes. Incluir, entre otras, las estructuras ya identificadas como LIDES, Colegial, Pipo, Asofútbol, Canguro, Diamante y sus diferentes divisiones/ediciones, sin asumir que esta lista es exhaustiva. Contrastar la información y no inventar datos.
</callout>

#

31. Frase resumen y visión

<quote color="blue_bg">
Una plataforma deportiva contextual que utiliza información estructurada y un sistema adaptable de agentes especializados para detectar necesidades, perfiles, oportunidades y soluciones, y convertirlas en matches y recomendaciones accionables para cada actor del ecosistema.
</quote>

#

32. Regla maestra del proyecto

<callout icon="📜" color="gray_bg">
No construir funciones porque podemos construirlas. Construir capacidades porque resuelven necesidades.

No añadir agentes porque suenan interesantes. Añadir agentes cuando una parte del proceso requiere una responsabilidad específica, contexto, reglas, frenos y un entregable.

No mostrar toda la complejidad al usuario. Utilizar la complejidad del sistema para entregar una experiencia simple.

Y antes de construir: entender el ecosistema real. Claude Code debe investigar exhaustivamente la estructura real de competiciones, divisiones, categorías, ediciones, clubes y demás entidades del fútbol venezolano; no diseñar la base de datos desde suposiciones.
</callout>

#

33. Estado actual de madurez (estimación cualitativa)

<i>Estos porcentajes son estimaciones de madurez conceptual, no mediciones objetivas.</i>

<table>
<tr>
<td>
Bloque
</td>
<td>
Madurez
</td>
</tr>
<tr>
<td>
Problema
</td>
<td>
100%
</td>
</tr>
<tr>
<td>
Visión del producto
</td>
<td>
100%
</td>
</tr>
<tr>
<td>
Matriz de Contexto
</td>
<td>
100%
</td>
</tr>
<tr>
<td>
Matriz de Casos
</td>
<td>
100%
</td>
</tr>
<tr>
<td>
Matriz de Necesidades
</td>
<td>
100%
</td>
</tr>
<tr>
<td>
Matriz de Matching
</td>
<td>
100%
</td>
</tr>
<tr>
<td>
Geo-inteligencia
</td>
<td>
80%
</td>
</tr>
<tr>
<td>
Actores
</td>
<td>
100%
</td>
</tr>
<tr>
<td>
Datos
</td>
<td>
90%
</td>
</tr>
<tr>
<td>
Relaciones
</td>
<td>
100%
</td>
</tr>
<tr>
<td>
Permisos / Visibilidad
</td>
<td>
100%
</td>
</tr>
<tr>
<td>
Flujos de experiencia
</td>
<td>
100%
</td>
</tr>
<tr>
<td>
Arquitectura conceptual
</td>
<td>
100%
</td>
</tr>
<tr>
<td>
MVP
</td>
<td>
55%
</td>
</tr>
<tr>
<td>
Priorización
</td>
<td>
100%
</td>
</tr>
<tr>
<td>
Arquitectura maestra de agentes
</td>
<td>
100%
</td>
</tr>
<tr>
<td>
Arquitectura de datos
</td>
<td>
100%
</td>
</tr>
<tr>
<td>
Arquitectura técnica
</td>
<td>
70%
</td>
</tr>
<tr>
<td>
Implementación
</td>
<td>
20%
</td>
</tr>
<tr>
<td>
Validación real
</td>
<td>
10%
</td>
</tr>
</table>

<callout icon="ℹ️">
- Contexto, Casos, Necesidades y Matching: reconstruidas con tabla completa en la sección 11-14; ya no hay brecha entre madurez declarada y contenido documentado.
</callout>

#

34. Dónde estamos ahora

```txt
IDEA → PROBLEMA ✓ → VISIÓN ✓ → ACTORES ✓ → CONTEXTO ✓ → CASOS ✓
→ NECESIDADES ✓ → MATCHING ✓ → GEO ◐ → DATOS ✓ → RELACIONES ✓
→ PERMISOS ✓ → EXPERIENCIAS ✓ → ARQUITECTURA ✓ (GATE TO PHASE 2 CUMPLIDO)
→ MVP ✓ (definición) → AGENTES ✓ → DATOS ✓ → STACK ✓ (definición)
→ IMPLEMENTACIÓN ← PRÓXIMO GRAN BLOQUE → VALIDACIÓN
```

<callout icon="🎯" color="yellow_bg">
<p>
Todavía no estamos en la etapa de "construir la aplicación completa". Estamos terminando la especificación estructural que permitirá construirla correctamente, antes de que Claude Code empiece a convertir todo esto en 
</p>
</callout>

#

35. Metodología de integración de agentes en la auditoría por etapa (decisión aplicada)

<callout icon="🤖" color="blue_bg">
Decisión del usuario: integrar los agentes ya definidos (Etapa 17 — agentes de producto; sección 19 — agentes de negocio/viabilidad) a la construcción de este documento, no solo dejarlos como especificación para el software futuro.
</callout>

<callout icon="⚠️" color="orange_bg">
Límite honesto: este entorno (Notion AI) no ejecuta código ni tiene runtime para los agentes del producto (Agente 1-4 Geo, Agente de Perfil, Contexto, Verificación de Datos, Permisos, Priorización) ni para los agentes de negocio. No existe una llamada de herramienta que los "active" de forma independiente.
</callout>

<callout icon="✅" color="green_bg">
Lo que sí es real y se aplica desde ahora: cada paso de la auditoría etapa por etapa se realiza <b>aplicando explícitamente el rol, la instrucción core y el freno</b> del agente que le corresponda según la Matriz de Agentes (Etapa 17) o los roles de negocio (sección 19), y cada hallazgo se etiqueta con qué agente-rol lo generó. Esto no es simulación decorativa: es aplicar de verdad la regla de ese agente (ej. el freno "no inventar datos" del Auditor QA) al trabajo documental, dejando trazabilidad de que se siguió. Cuando el software real exista en Antigravity, estos mismos roles se convertirán en procesos ejecutables; aquí son el mismo contrato aplicado manualmente por el documentador.
</callout>

#

36. Backlog de datos bloqueados por acceso externo (pendientes de integración futura)

<callout icon="🔒" color="gray_bg">
Esta sección consolida, al cierre del roadmap, toda la información que la columna vertebral necesita idealmente pero que <b>no podemos trabajar ni verificar ahora mismo</b> por falta de acceso a sistemas externos (no por falta de definición conceptual). No se descarta ni se inventa: queda documentada como dependencia externa conocida, para retomarla cuando se gestione el acceso correspondiente — típicamente en la Etapa 18-19 (Arquitectura de datos/técnica) o ya construyendo la plataforma.
</callout>

<table>
<tr>
<td>
Dato bloqueado
</td>
<td>
Fuente que lo resolvería
</td>
<td>
Por qué está bloqueado ahora
</td>
<td>
Entidad / Etapa afectada
</td>
<td>
Prioridad al retomar
</td>
</tr>
<tr>
<td>
Nómina oficial de jugadores por club (competiciones afiliadas a la FVF)
</td>
<td>
Sistema COMET (FVF / asociaciones regionales)
</td>
<td>
Requiere API key otorgada formalmente por la FVF o la asociación regional; no es de acceso público
</td>
<td>
Jugador — atributo "club actual" (Etapa 10)
</td>
<td>
Alta
</td>
</tr>
<tr>
<td>
Historial de clubes verificado (traspasos oficiales)
</td>
<td>
Sistema COMET, módulo de traspasos
</td>
<td>
Mismo bloqueo de acceso que la nómina; sin credenciales no hay contraste oficial
</td>
<td>
Jugador — atributo "historial de clubes", ahora obligatorio (Etapa 10)
</td>
<td>
Alta
</td>
</tr>
<tr>
<td>
Estructura oficial completa de categorías/divisiones/temporadas de ligas privadas (Canguro, Diamante, Pipo, LIDES, Colegial)
</td>
<td>
Sitios y redes propias de cada liga; sin sistema centralizado tipo COMET confirmado
</td>
<td>
No existe una fuente única ni API; requiere investigación manual liga por liga, sin garantía de actualización
</td>
<td>
Competición, Categoría/División, Temporada (entidades de soporte, Etapa 10)
</td>
<td>
Media
</td>
</tr>
<tr>
<td>
Datos institucionales verificados de clubes/academias (precios, horarios, servicios, staff)
</td>
<td>
Sitios propios / redes sociales de cada club o academia
</td>
<td>
Información dispersa y no centralizada; requiere investigación exhaustiva y actualización periódica manual (ver regla de la sección 10)
</td>
<td>
Club, Academia (Etapa 10)
</td>
<td>
Media
</td>
</tr>
<tr>
<td>
Verificación de certificaciones de profesionales (entrenador, fisioterapeuta, preparador físico)
</td>
<td>
Colegios/asociaciones profesionales, FVF
</td>
<td>
Sin integración ni acceso definido; depende de organismos regulatorios externos
</td>
<td>
Entrenador, Fisioterapeuta, Preparador físico (Etapa 10)
</td>
<td>
Media-Baja
</td>
</tr>
<tr>
<td>
Datos de tryouts en tiempo real (fecha, cupo, requisitos)
</td>
<td>
Cada club/academia publica por su cuenta (redes sociales, sitios propios)
</td>
<td>
Sin fuente unificada; requeriría scraping o investigación continua sin sistema de acceso formal
</td>
<td>
Tryout (entidad de soporte, Etapa 10)
</td>
<td>
Media
</td>
</tr>
</table>

<callout icon="📌">
Decisión fijada: esta información <b>no se trabaja ahora</b> por tema de acceso, pero es clave para la columna vertebral y se retomará más adelante. Mientras tanto sirve para: (1) diseñar la Arquitectura de Datos (Etapa 18) dejando espacio explícito para estos campos como "verificado externamente: pendiente", (2) anticipar en la Arquitectura Técnica (Etapa 19) los puntos de integración (API COMET, scraping controlado, carga manual verificada), y (3) priorizar, cuando se construya la plataforma, las gestiones de acceso institucional (FVF, asociaciones regionales) antes de automatizar estos flujos.
</callout>

<p />

<page url="https://app.notion.com/p/b4d7b0cab8324dc7ba3792bba0fca2d6">
Paquete de Transferencia a Antigravity (repo futebolfer/futbol)
</page>
