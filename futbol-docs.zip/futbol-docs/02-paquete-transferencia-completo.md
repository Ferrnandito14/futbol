# Paquete de Transferencia a Antigravity (repo futebolfer/futbol)

> Objetivo: dejar todo lo construido — documento maestro + las 6 Skills con sus subagentes — listo para migrar al repositorio **github.com/futebolfer/futbol**, de modo que Antigravity pueda continuar exactamente desde este punto. Este entorno no puede hacer push a GitHub (regla 43): el contenido de abajo está pensado para copiar/pegar en archivos del repo, o para pegar directamente en el chat de Antigravity una vez conectado al repositorio.

## 1. Qué se transfiere y a dónde

| Contenido | Origen (Notion) | Archivo destino sugerido | Cómo migrarlo |
|---|---|---|---|
| Documento maestro completo (Etapas 1-19, matrices, reglas, backlog) | STARTUP DEPORTIVA — Master Roadmap + Columna Vertebral | `/docs/spec/00-master-roadmap.md` | Usar el archivo `00-ROADMAP-MAESTRO.md` incluido en este paquete |
| Pipeline de 9 (ahora 15) agentes de producto (Etapa 17) + arquitectura de datos (Etapa 18) + stack técnico (Etapa 19) | Secciones correspondientes del documento maestro | `/docs/spec/09-agentes-producto.md`, `10-arquitectura-datos.md`, `11-arquitectura-tecnica.md` | Opcional: aislar esas secciones en archivos propios para que Antigravity los lea primero |
| Skill Fase 0 — Auditoría Digital (IADM) + 4 subagentes | Skill Fase 0 | `/docs/skills/fase-0-auditoria-digital.md` | Incluido en `skills/` |
| Skill Fase 1 — Plano Digital de Marca + 5 subagentes | Skill Fase 1 | `/docs/skills/fase-1-plano-digital.md` | Incluido en `skills/` |
| Skill Fase 2 — Construcción y Lanzamiento + 5 subagentes | Skill Fase 2 | `/docs/skills/fase-2-construccion-lanzamiento.md` | Incluido en `skills/` |
| Skill Fase 3 — Habitabilidad Digital + 5 subagentes | Skill Fase 3 | `/docs/skills/fase-3-habitabilidad-digital.md` | Incluido en `skills/` |
| Skill Fase 4 — Escalamiento y Growth + 5 subagentes | Skill Fase 4 | `/docs/skills/fase-4-escalamiento-growth.md` | Incluido en `skills/` |
| Skill Fase Geo — Inteligencia Geográfica + 4 subagentes | Skill Fase Geo | `/docs/skills/fase-geo-inteligencia-geografica.md` | Incluido en `skills/` |

> **Distinción importante que debe conservarse en el repo:** las Skills de Fase 0-4 son **agentes de negocio/growth** (operan la construcción y crecimiento del proyecto/startup); la Skill Fase Geo y el pipeline de agentes de la Etapa 17 son **agentes de producto** (operan dentro de la plataforma en tiempo real, para cada usuario). No fusionar ambos grupos al implementar.

## 2. AGENTS.md raíz sugerido para el repo

Ver archivo `01-AGENTS-raiz-sugerido.md` incluido en este paquete — cópialo como `/AGENTS.md` en la raíz de `futebolfer/futbol`.

## 3. Contenido íntegro de las Skills y subagentes

El contenido completo de cada Skill (rol, parámetros, instrucciones, salida de cada subagente) está en los archivos individuales dentro de la carpeta `skills/`:

- `skills/fase-0-auditoria-digital.md`
- `skills/fase-1-plano-digital.md`
- `skills/fase-2-construccion-lanzamiento.md`
- `skills/fase-3-habitabilidad-digital.md`
- `skills/fase-4-escalamiento-growth.md`
- `skills/fase-geo-inteligencia-geografica.md`

---

Con este paquete + el export en Markdown del documento maestro, hay todo lo necesario para poblar `futebolfer/futbol` y continuar en Antigravity exactamente desde este punto: especificación completa (Etapas 1-19) + agentes de producto (Etapa 17 + Geo, 15 agentes) + agentes de negocio/growth (Fases 0-4) con sus subagentes y frenos.
