# STARTUP DEPORTIVA — Paquete para github.com/futebolfer/futbol

Este paquete contiene la especificación completa construida hasta ahora en Notion AI, lista para subir al repositorio y continuar la implementación en Antigravity.

## Estructura sugerida al subir

```
/AGENTS.md                                          <- copiar desde 01-AGENTS-raiz-sugerido.md
/docs/spec/00-master-roadmap.md                     <- desde 00-ROADMAP-MAESTRO.md
/docs/skills/fase-0-auditoria-digital.md
/docs/skills/fase-1-plano-digital.md
/docs/skills/fase-2-construccion-lanzamiento.md
/docs/skills/fase-3-habitabilidad-digital.md
/docs/skills/fase-4-escalamiento-growth.md
/docs/skills/fase-geo-inteligencia-geografica.md
```

## Contenido de este ZIP

- `00-ROADMAP-MAESTRO.md` — documento maestro completo (Etapas 1-19: definición, actores, datos, relaciones, permisos, flujos, arquitectura conceptual, MVP, priorización, arquitectura de agentes de producto, arquitectura de datos, arquitectura técnica, investigación del fútbol venezolano, reglas 1-45, backlog de datos bloqueados). Incluye la solución aplicada esta sesión: 6 grupos contextuales de entrada en la interfaz (Jugadores, Niño/Familia, Clubes, Academias, Profesionales, Scouts).
- `01-AGENTS-raiz-sugerido.md` — bloque sugerido para `/AGENTS.md` en la raíz del repo, para que Antigravity no invente arquitectura y siga el orden de lectura correcto.
- `02-paquete-transferencia-completo.md` — página completa "Paquete de Transferencia a Antigravity", con la tabla de mapeo origen→destino y el contenido íntegro de las 6 Skills (Fase 0-4 + Geo) con todos sus subagentes.
- `skills/fase-0-auditoria-digital.md`
- `skills/fase-1-plano-digital.md`
- `skills/fase-2-construccion-lanzamiento.md`
- `skills/fase-3-habitabilidad-digital.md`
- `skills/fase-4-escalamiento-growth.md`
- `skills/fase-geo-inteligencia-geografica.md`

## Estado del proyecto

- Especificación (Etapas 1-19): completa a nivel conceptual/documental.
- Implementación (Etapa 20 en adelante): no iniciada. Este paquete es el punto de partida para Antigravity.
- Bloqueado por acceso externo (no técnico): integración con sistema COMET (ver backlog en el roadmap maestro).
