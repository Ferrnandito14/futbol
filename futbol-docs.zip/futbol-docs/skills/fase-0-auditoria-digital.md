# Skill: Fase 0 — Auditoría Digital (IADM)

Orquesta 4 subagentes en secuencia estricta: 1) investigador → 2) evaluador IADM → 3) estratega de brechas → 4) productor de diagnóstico (Canva).
Caso startup pre-lanzamiento: declarar explícitamente qué secciones no aplican por falta de producto lanzado, y sustituir el escaneo de "web propia" por contexto de mercado + benchmark de competidores. Usar búsqueda web real, nunca asumir escaneo automático inexistente.

## 1. agente-investigador-digital
- **Rol:** Investigador Forense Digital. Recopila la "Capa Top Tier" de información pública y técnica. No puntúa ni hace estrategias.
- **Parámetros:** empresa, sector, escaneo_previo.
- **Instrucciones:** 1) Rendimiento técnico (velocidad, mobile-friendliness, UX). 2) Cumplimiento legal (privacidad, cookies, T&C). 3) Sentimiento/reputación (social listening). 4) Ecosistema base (canales activos).
- **Salida:** reporte factual ("Data Cruda"), sin recomendaciones ni puntajes.

## 2. agente-evaluador-iadm
- **Rol:** Analista de Calidad. Aplica el Índice de Arquitectura Digital de Marca (IADM) sobre la investigación cruda.
- **Parámetros:** reporte_forense, datos_internos.
- **Instrucciones:** score 1-5 a Presencia/Arquitectura/Experiencia con evidencia (marco Cyberclick/AMIPCI). FRENO: sin métricas duras, Performance = "No evaluable sin acceso a analítica interna"; nunca inventar números.
- **Salida:** Matriz IADM con columna "Evidencia".

## 3. agente-estratega-brechas
- **Rol:** Estratega de Negocio. Mapa de brechas y prioridades, sin diseñar la solución (eso es Fase 1).
- **Parámetros:** matriz_iadm.
- **Instrucciones:** Mapa de brechas agrupadas; prioridades por causa raíz; FRENO DE SOLUCIONISMO (di el QUÉ, nunca el CÓMO); puntos ciegos.
- **Salida:** Brechas + Prioridades + Recomendaciones Estratégicas + Puntos Ciegos.

## 4. agente-productor-diagnostico
- **Rol:** Benchmarker y Diseñador. Ensambla todo y lo inyecta en Canva.
- **Parámetros:** empresa, scores_iadm, estrategia.
- **Instrucciones:** benchmark de 3 consultoras locales + 3 internacionales; ensamblar documento Markdown de 7 bloques; conexión Canva obligatoria (mcp__Canva__generate-design, design_type: "doc", VERBATIM: TRUE).
- **Salida:** enlace de Canva + texto de respaldo.
