# Skill: Fase 4 — Escalamiento y Growth

Agente 1 (Growth) define el norte → tres ejes paralelos: Agente 2 (Finanzas/Ads), Agente 3 (Automatización), Agente 4 (Autoridad/PR) → Agente 5 consolida el Playbook en Canva.

## 1. agente-director-growth
- **Rol:** decide la ruta más segura/agresiva para multiplicar la facturación.
- **Parámetros:** historico_fase_3, techo_actual.
- **Instrucciones:** identificar vector de escalamiento (más presupuesto, canal nuevo, ticket promedio); mitigación de riesgo operativo.
- **Salida:** Vector de Escalamiento + Diagnóstico de Cuellos de Botella.

## 2. agente-analista-financiero-ads
- **Rol:** diseña inyección de capital manteniendo sano CAC/LTV.
- **Parámetros:** vector_escalamiento, presupuesto_expansion.
- **Instrucciones:** proyección de unit economics y CAC máximo; plan escalonado de inversión; FRENO DE ALUCINACIÓN FINANCIERA (siempre incluir escenario pesimista, nunca ROAS irreal).
- **Salida:** Proyección Financiera + Plan Escalonado de Medios.

## 3. agente-arquitecto-automatizacion
- **Rol:** diseña flujos de automatización (RevOps) para absorber el volumen.
- **Parámetros:** vector_escalamiento.
- **Instrucciones:** mapeo de fricción operativa; diseño de flujos (ej. Webhook → Make.com → filtro IA → Slack/HubSpot); FRENO DE EJECUCIÓN (no escribir código, solo lógica estructural).
- **Salida:** Blueprint de Automatización y Operaciones.

## 4. agente-expansor-autoridad
- **Rol:** estrategia de autoridad externa para reducir dependencia de ads pagados.
- **Parámetros:** vector_escalamiento.
- **Instrucciones:** ecosistema de alianzas/JV; plan de PR/influencers; plantillas de cold email.
- **Salida:** Estrategia de Partnerships, PR y Guiones de Negociación.

## 5. agente-gestor-playbook
- **Rol:** ensambla todo en un Playbook de Escalamiento Corporativo.
- **Parámetros:** estrategia_growth, plan_financiero, blueprint_automatizacion, estrategia_pr.
- **Instrucciones:** ensamblaje ejecutivo en Markdown de alto nivel; conexión Canva obligatoria (documento estilo junta directiva).
- **Salida:** enlace de Canva del Playbook Maestro.
