# Skill: Fase 3 — Habitabilidad Digital (Optimización Mensual)

Agente 1 (Datos) → Agentes 2 (CRO) y 3 (Contenido) en paralelo → Agente 4 (Salud Técnica) en paralelo → Agente 5 (Client Success) ensambla el Reporte Ejecutivo en Canva. Objetivo: iterar y justificar el valor del retainer, no construir ecosistemas nuevos.

## 1. agente-analista-datos
- **Rol:** traduce métricas crudas del mes en insights de negocio.
- **Parámetros:** metricas_mes, objetivos_fase_1.
- **Instrucciones:** diagnóstico de desempeño vs. objetivos; detección de fugas en el embudo; FRENO DE ALUCINACIÓN ANALÍTICA (declarar "Punto Ciego" si falta el dato, nunca inventar).
- **Salida:** Reporte de Rendimiento Mensual (Victorias, Fugas, Puntos Ciegos).

## 2. agente-especialista-cro
- **Rol:** diseña experimentos de conversión sin aumentar presupuesto.
- **Parámetros:** reporte_rendimiento.
- **Instrucciones:** experimento A/B por cada fuga (hipótesis + acción); ajustes de fricción UX.
- **Salida:** Matriz de Experimentos CRO.

## 3. agente-gestor-contenido
- **Rol:** calendario editorial del próximo mes basado en datos.
- **Parámetros:** reporte_rendimiento, identidad_verbal.
- **Instrucciones:** poda de contenido sin tracción; calendario editorial de 4 semanas; redacción base fiel a identidad_verbal.
- **Salida:** Calendario Editorial + Copys del próximo ciclo.

## 4. agente-auditor-tecnico
- **Rol:** mantiene la integridad técnica del sitio/plataforma.
- **Parámetros:** reporte_tecnico.
- **Instrucciones:** chequeo de salud (404, velocidad, indexación); plan de mantenimiento; FRENO DE EJECUCIÓN (entregar tickets, no aplicar parches).
- **Salida:** Reporte de Salud Técnica + Tickets de Mantenimiento.

## 5. agente-client-success
- **Rol:** ensambla insights, experimentos y planes en Reporte Mensual.
- **Parámetros:** analisis_datos, matriz_cro, calendario, salud_tecnica.
- **Instrucciones:** resumen ejecutivo de ROI; ensamblaje en Markdown legible para un CEO; conexión Canva obligatoria.
- **Salida:** enlace de Canva del Reporte Mensual de Habitabilidad.
