# Skill: Fase 1 — Plano Digital de Marca (Blueprint)

Cadena lineal estricta: Agente 1 (Viabilidad) → Agentes 2 y 3 (Ecosistema y Mensaje) → Agente 4 (Criterios de Aceptación) → Agente 5 (Productor y Canva). Freno de Ejecución: no se genera código ni elementos finales en esta fase.

## 1. agente-analista-viabilidad
- **Rol:** traduce brechas en requerimientos lógicos, filtra viabilidad operativa/presupuestaria.
- **Parámetros:** diagnostico_fase_0, datos_directos.
- **Instrucciones:** FRENO DE SUPUESTOS (declarar "supuesto a confirmar" si faltan datos reales); mapeo de requerimientos; viabilidad operativa; FRENO DE DISEÑO (no resolver aún).
- **Salida:** Requerimientos Base + Matriz de Viabilidad Operativa.

## 2. agente-arquitecto-ecosistema
- **Rol:** diseña canales, embudos, sitemap, stack técnico/legal.
- **Parámetros:** requerimientos_base.
- **Instrucciones:** arquitectura de canales/embudos; sitemap/wireframe lógico; stack técnico y legal; FRENO DE EJECUCIÓN (no generar código ni copy final).
- **Salida:** Blueprint Estructural + Embudos + Requerimientos Técnicos.

## 3. agente-arquitecto-mensaje
- **Rol:** identidad verbal, pilares de contenido, ganchos de conversión.
- **Parámetros:** requerimientos_base, blueprint_estructural.
- **Instrucciones:** tono/voz; pilares de contenido; hooks de conversión; FRENO DE EJECUCIÓN (no copys finales).
- **Salida:** Matriz de Identidad Verbal + Guía de Mensajería.

## 4. agente-criterios-aceptacion
- **Rol:** define criterios que la Fase 2 debe cumplir (Gate to Phase 2).
- **Parámetros:** blueprint, identidad_verbal.
- **Instrucciones:** indicadores claros y medibles; criterios de calidad (qué se acepta/rechaza).
- **Salida:** Criterios de Aceptación + Protocolo de Transición.

## 5. agente-productor-plano
- **Rol:** ensambla todo en documento maestro y lo exporta a Canva.
- **Parámetros:** requerimientos, blueprint, identidad_verbal, criterios.
- **Instrucciones:** ensamblaje maestro en Markdown; conexión Canva obligatoria (VERBATIM: TRUE).
- **Salida:** enlace de Canva del Plano Maestro + condiciones para Fase 2.
