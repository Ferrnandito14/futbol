# Skill: Fase Geo — Inteligencia Geográfica (agentes de PRODUCTO, no de negocio)

Cascada estricta: Agente 1 (Contexto/Privacidad) → Agente 2 (Descubrimiento) → Agente 3 (Fricción) → Agente 4 (Matching). Enriquece datos antes de presentarlos al usuario; no reemplaza al motor principal. Nunca revelar APIs ni exponer coordenadas exactas de menores.

## 1. agente-contexto-privacidad
- **Rol:** entiende dónde está el usuario y qué nivel de exposición es seguro.
- **Parámetros:** datos_entrada (GPS/IP/manual), perfil_usuario (edad, preferencias).
- **Instrucciones:** interpretar entrada como área geográfica útil; FILTRO DE SEGURIDAD crítico (ofuscar coordenadas si es menor, nunca asumir que la ubicación debe ser pública); fallback a entrada manual si no hay GPS.
- **Salida:** Objeto "Ubicación de Trabajo" con nivel de precisión y estado de permisos.

## 2. agente-descubrimiento-calidad
- **Rol:** puente con APIs externas de mapas y limpieza de datos.
- **Parámetros:** ubicacion_trabajo, criterio_busqueda.
- **Instrucciones:** búsqueda restringida al MVP; auditoría de calidad (duplicados, coordenadas incompletas); enriquecimiento seguro sin exponer claves de API.
- **Salida:** Lista limpia y enriquecida de Entidades Georreferenciadas.

## 3. agente-analisis-friccion
- **Rol:** calcula costo real de desplazamiento, no solo distancia radial.
- **Parámetros:** entidades_limpias, ubicacion_trabajo.
- **Instrucciones:** cálculo de tiempo/modo de transporte; contexto de ruta si está disponible.
- **Salida:** Matriz de Entidades con Puntuación de Fricción de Movimiento.

## 4. agente-matching-geografico
- **Rol:** cruza ubicación física con realidad deportiva del usuario (la ubicación es una variable, no el criterio absoluto).
- **Parámetros:** matriz_friccion, contexto_deportivo (nivel, categoría, urgencia).
- **Instrucciones:** cruce multidimensional (ej. no priorizar cercanía sobre ventana de tiempo/nivel competitivo cuando hay urgencia); salida conversacional y justificada.
- **Salida:** Recomendaciones finales de matching geográfico.
